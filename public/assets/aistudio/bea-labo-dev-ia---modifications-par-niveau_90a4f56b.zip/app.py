import ast
import base64
import difflib
import html
import io
import json
import os
import re
import time
import zipfile
from collections import deque
from datetime import datetime, timezone

import streamlit as st
import streamlit.components.v1 as components
from groq import Groq
from PIL import Image, ImageDraw, ImageFont, ImageOps
from supabase import create_client

try:
    from andrea_utils import (
        PALETTES,
        clean_text,
        cues_to_srt,
        cues_to_vtt,
        extract_html,
        image_to_png_bytes,
        make_thumbnail,
        script_to_cues,
        segments_to_cues,
    )
except ImportError:
    from bea_utils import (
        PALETTES,
        clean_text,
        cues_to_srt,
        cues_to_vtt,
        extract_html,
        image_to_png_bytes,
        make_thumbnail,
        script_to_cues,
        segments_to_cues,
    )

def find_file(cands):
    for f in cands:
        if os.path.exists(f):
            return f
    return None

LOGO = find_file(["logo_andrea.png", "logo_bea.png", "logo.png", "logo_andrea.svg", "logo_bea.svg"])
try:
    _icon = Image.open(LOGO) if LOGO else "🧠"
except Exception:
    _icon = "🧠"

try:
    from andrea_i18n import setup_i18n, tr, current_lang, render_language_selector, language_instruction, flush_translations
    HAS_I18N = True
except Exception:
    try:
        from bea_i18n import setup_i18n, tr, current_lang, render_language_selector, language_instruction, flush_translations
        HAS_I18N = True
    except Exception:
        HAS_I18N = False

try:
    from andrea_voice import render_voice_button, render_voice_player, render_voice_settings, queue_autoplay
    HAS_VOICE = True
except Exception:
    try:
        from bea_voice import render_voice_button, render_voice_player, render_voice_settings, queue_autoplay
        HAS_VOICE = True
    except Exception:
        HAS_VOICE = False

st.set_page_config(page_title="Andrea", page_icon=_icon, layout="wide", initial_sidebar_state="expanded")
if HAS_I18N:
    try:
        setup_i18n()
    except Exception:
        pass
AVATAR = LOGO or "🧠"

STRIPE_ANDREA_9 = "https://buy.stripe.com/test_8x27sMei58IC6Rg3OM3wQ01"
STRIPE_PRO_1490 = "https://buy.stripe.com/test_cNieVea1P0c62B08523wQ00"
STRIPE_ABO_16 = "https://buy.stripe.com/test_8x27sMei58IC6Rg3OM3wQ01"

try:
    GROQ_KEY = st.secrets["GROQ_API_KEY"]
    SUPA_URL = st.secrets["SUPABASE_URL"]
    SUPA_KEY = st.secrets.get("SUPABASE_ANON_KEY") or st.secrets.get("SUPABASE_KEY")
    if not SUPA_KEY:
        raise KeyError("SUPABASE_ANON_KEY")
    DEV_ACCESS_KEY = st.secrets.get("DEV_ACCESS_KEY", "")
    DEV_EMAIL = st.secrets.get("DEV_EMAIL", "saydoukebe31@gmail.com")
except Exception:
    st.error("Configuration manquante : GROQ_API_KEY, SUPABASE_URL et SUPABASE_ANON_KEY doivent être définis dans les secrets.")
    st.stop()

CONTACT_EMAIL = st.secrets.get("CONTACT_EMAIL", "")
REQUIRE_LOGIN_CODE = str(st.secrets.get("REQUIRE_LOGIN_CODE", "false")).strip().lower() in ("1", "true", "yes", "oui")

PLANS = ("free", "bea", "pro", "abo")
PLAN_LABEL = {"free": "Gratuit", "bea": "Andrea", "pro": "Andrea Pro", "abo": "Andrea Ultra"}
WHISPER_MODEL = "whisper-large-v3-turbo"
MAX_AUDIO_BYTES = 25 * 1024 * 1024
EXT = {"python": "py", "javascript": "js", "typescript": "ts", "html": "html", "css": "css", "json": "json", "sql": "sql"}
DEFAULT_CODE = ""

STARTER_CARDS = {
    "entreprise": [
        "Structurer ma délégation et les priorités de la semaine",
        "Créer une routine d'équipe régulière et autonome",
        "Trancher une décision stratégique complexe avec clarté",
    ],
    "independant": [
        "Optimiser ma prospection client et mon taux de conversion",
        "Revaloriser mon offre et mes tarifs avec assurance",
        "Construire un rythme de travail stable et performant",
    ],
    "createur": [
        "Structurer une vidéo virale avec forte rétention dès le hook",
        "Diviser par 3 mon temps de production et de montage",
        "Créer une ligne éditoriale percutante pour ce mois",
    ],
    "etudiant": [
        "Méthode d'assimilation active pour un cours complexe",
        "Plan de révision par répétition espacée sans surcharge",
        "Démarrer une session d'étude efficace de 45 minutes",
    ],
    "salarie": [
        "Clarifier mes priorités et reprendre le contrôle de mon agenda",
        "Préparer un échange stratégique avec mon équipe ou direction",
        "Construire mon plan d'évolution et d'impact professionnel",
    ],
    "recherche_emploi": [
        "Optimiser la présentation de mon parcours en entretien",
        "Cibler les opportunités clés et maximiser mes candidatures",
        "Clarifier ma trajectoire professionnelle et mes points forts",
    ],
    "parent": [
        "Harmoniser mes projets personnels et mon organisation familiale",
        "Créer des blocs de temps dédiés à mes priorités clés",
        "Mettre en place des routines quotidiennes sereines et efficaces",
    ],
    "enseignant": [
        "Structurer une séquence pédagogique interactive et engageante",
        "Déconstruire une notion difficile avec la méthode Feynman",
        "Renforcer l'ancrage et la mémorisation durable des élèves",
    ],
    "autre": [
        "Transformer une idée en plan d'action concret en 3 étapes",
        "Définir mes priorités stratégiques pour la semaine",
        "Construire une routine quotidienne productive et durable",
    ],
}

@st.cache_resource
def get_groq():
    return Groq(api_key=GROQ_KEY)

@st.cache_data(ttl=3600)
def get_modeles():
    pref_fast = ["llama-3.1-8b-instant", "llama-3.3-70b-versatile"]
    pref_power = ["llama-3.3-70b-versatile", "llama-3.1-70b-versatile"]
    try:
        ids = [m.id for m in get_groq().models.list().data]
        chat_ids = [i for i in ids if "whisper" not in i and "guard" not in i]
        fast = [m for m in pref_fast if m in chat_ids] or chat_ids[:2]
        power = [m for m in pref_power if m in chat_ids] or chat_ids[:2]
        return {"rapide": fast, "puissant": power}
    except Exception:
        return {"rapide": pref_fast[:1], "puissant": pref_power[:1]}

DEV_MODELES = {
    "Ultra (gratuit) - Llama 3.3 70B [RECOMMANDÉ]": "llama-3.3-70b-versatile",
    "Rapide (gratuit) - Llama 3.1 8B Instant": "llama-3.1-8b-instant",
}

def now_iso():
    return datetime.now(timezone.utc).isoformat()

for k, v in {
    "page": "chat", "sb": None, "user": None, "plan": "free", "quota": {}, "prefs": {},
    "conv_id": None, "messages": [], "convs": None, "projects": None,
    "code_messages": [], "code_project_id": None, "code_name_in": "", "code_lang_in": "python",
    "rate": deque(), "blocked_until": 0.0, "up_key": 0, "expanded": None, "auth_notice": "", "pending_confirmation_email": "",
    "sub_result": None, "plan_result": None, "app_result": None, "app_versions": [], "app_generation_count": 0, "thumb_png": None, "pending_login": None, "is_admin": False,
    "model_choice": "rapide", "search_q": "", "editing_msg_id": None, "studio_menu": "importer", "memories": None, "profile_type": "createur",
    "dev_mode": None, "dev_result": None, "dev_raw": None, "dev_key_ok": False, "dev_model_choice": "Ultra (gratuit) - Llama 3.3 70B [RECOMMANDÉ]",
    "dev_full_original": "", "dev_backup_name": "", "transcribed_text": "",
    "onboarding_step": 1, "onboarding_profile": "createur", "onboarding_profile_choice": "createur", "onboarding_goal_choice": "clients", "onboarding_goal": "", "onboarding_goal_text": "", "onboarding_study_country": "France", "onboarding_study_level": "Collège - 6e", "landing_tab": "connexion",
    "canvas_png": None, "canvas_zip": None,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v
if "code_area" not in st.session_state:
    st.session_state["code_area"] = DEFAULT_CODE

GRAD = "linear-gradient(90deg, #1E1B8C 0%, #5A33FF 100%)"
BORDER, BG, CARD, TEXT, TEXT_SEC, ACCENT = "#5A33FF44", "#181135", "#231a4a", "#FFFFFF", "#c4b5fd", "#8B70FF"
st.markdown(f"""
<style>
html, body, .stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"], section.main {{background:#181135!important; color:#FFFFFF!important;}}
[data-testid="stSidebar"], [data-testid="stSidebar"] > div {{background:#150f2e!important; border-right:1px solid rgba(124,58,237,0.25)!important;}}
[data-testid="stSidebar"] *{{color:#e4e4e7!important;}}
header[data-testid="stHeader"]{{background:#181135!important; border-bottom:1px solid rgba(124,58,237,0.2)!important;}}
.block-container{{max-width:1440px!important; width:100%!important; padding-top:5rem!important; padding-bottom:7rem!important;}}
#MainMenu,footer{{visibility:hidden;}}
div[data-testid="stButton"]>button{{background:#231a4a!important; color:#FFFFFF!important; border:1px solid #5A33FF66!important; border-radius:12px!important; font-weight:600!important; font-size:13px!important; min-height:44px!important; transition:all 0.2s ease!important;}}
div[data-testid="stButton"]>button:hover{{background:#2e2260!important; border-color:#8B70FF!important; box-shadow:0 0 12px rgba(90,51,255,0.3)!important;}}
div[data-testid="stButton"]>button[kind="primary"], div[data-testid="stButton"]>button[data-testid="baseButton-primary"]{{background:{GRAD}!important; color:white!important; border:none!important; font-weight:700!important; box-shadow:0 4px 14px rgba(90,51,255,0.35)!important;}}
div[data-testid="stLinkButton"]>a{{background:{GRAD}!important; color:white!important; border-radius:12px!important; font-weight:700!important; border:none!important; padding:12px!important; box-shadow:0 4px 14px rgba(90,51,255,0.3)!important;}}
div[data-testid="stChatMessage"]{{background:{CARD}!important; border:1px solid {BORDER}!important; border-radius:16px!important; padding:14px!important; box-shadow:0 4px 20px rgba(15,10,35,0.6)!important; max-width:920px!important; margin-left:auto!important; margin-right:auto!important;}}
div[data-testid="stChatMessage"] p{{color:{TEXT}!important; font-size:15px!important; line-height:1.6!important;}}
div[data-baseweb="input"], div[data-baseweb="textarea"], div[data-baseweb="select"]>div{{background:#201844!important; border:1px solid #5A33FF44!important; border-radius:12px!important;}}
div[data-baseweb="base-input"]{{background:transparent!important; border:none!important;}}
div[data-baseweb="input"] input, div[data-baseweb="textarea"] textarea, div[data-baseweb="select"] input{{background:transparent!important; color:{TEXT}!important; border:none!important; box-shadow:none!important; outline:none!important;}}

/* Discussion box - Large 2-tier card matching preview perfectly (Image 3) */
div[data-testid="stChatInput"]{{
    max-width:920px!important; margin:0 auto!important; width:100%!important;
    background:#201844!important; border:1px solid #5A33FF55!important; border-radius:24px!important;
    padding-top:12px!important; padding-left:14px!important; padding-right:14px!important; padding-bottom:48px!important;
    min-height:98px!important; box-shadow:0 4px 24px rgba(15,10,35,0.6)!important;
    position:relative!important; box-sizing:border-box!important;
    transition:border-color 0.2s ease, box-shadow 0.2s ease!important;
}}
div[data-testid="stChatInput"]:focus-within{{
    border-color:#8B70FF!important;
    box-shadow:0 0 16px rgba(139,112,255,0.3)!important;
}}
div[data-testid="stChatInput"] > div,
div[data-testid="stChatInput"] [data-baseweb="base-input"]{{
    position:static!important; background:transparent!important; border:none!important; box-shadow:none!important; width:100%!important;
}}
div[data-testid="stChatInput"] textarea{{
    padding:2px 4px!important; min-height:42px!important;
    font-size:15px!important; line-height:1.5!important;
    background:transparent!important; color:#FFFFFF!important;
    border:none!important; outline:none!important; box-shadow:none!important; width:100%!important; box-sizing:border-box!important;
    resize:none!important;
}}
div[data-testid="stBottom"]{{background:transparent!important; position:relative!important;}}
div[data-testid="stBottom"]>div{{background:transparent!important; max-width:920px!important; margin:0 auto!important;}}
.bea-hero-title{{font-size:34px; font-weight:800; color:{TEXT}; text-align:center; margin:8px 0 2px 0; letter-spacing:-0.5px;}}
.bea-hero-sub{{font-size:12px; color:{TEXT_SEC}!important; text-align:center; font-weight:600; letter-spacing:0.8px; margin-bottom:16px;}}
.desc-main{{font-size:14px; color:{TEXT_SEC}; text-align:center; max-width:760px; margin:12px auto 32px auto; line-height:1.7;}}
.landing-copy{{max-width:820px; margin:18px auto 34px auto; padding:24px 30px; background:{CARD}; border:1px solid {BORDER}; border-radius:18px; text-align:center; box-shadow:0 8px 32px rgba(15,10,35,0.8);}}
.landing-copy h2{{color:{TEXT}; font-size:23px; margin:0 0 14px 0; line-height:1.25;}}
.landing-copy p{{color:#d4ccff; font-size:15px; line-height:1.75; margin:10px 0;}}
.landing-copy strong{{color:#ffffff;}}
@media (max-width:700px){{.landing-copy{{padding:20px 18px;}} .landing-copy h2{{font-size:20px;}} .landing-copy p{{font-size:14px;}}}}
.limit-badge{{background:#231a4a; border:1px solid {BORDER}; border-radius:8px; padding:6px 10px; font-size:11px; color:{TEXT_SEC}; margin-bottom:10px;}}
.soon{{font-size:12px; color:#7a70a8;}}

/* Send button styling - EXACT 36px circular button at bottom-right (right:14px) */
div[data-testid="stChatInput"] button[data-testid="stChatInputSubmitButton"],
div[data-testid="stChatInput"] button[aria-label*="Send"],
div[data-testid="stChatInput"] button[aria-label*="Envoyer"]{{
    position:absolute!important; right:14px!important; bottom:8px!important; top:auto!important; left:auto!important; z-index:30!important;
    width:36px!important; height:36px!important; min-width:36px!important; min-height:36px!important; max-width:36px!important; max-height:36px!important;
    border-radius:50%!important; background:#ffffff!important; color:#181135!important;
    border:none!important; display:flex!important; align-items:center!important; justify-content:center!important;
    padding:0!important; margin:0!important; box-shadow:0 2px 8px rgba(0,0,0,0.4)!important; cursor:pointer!important;
    transform:none!important;
}}
div[data-testid="stChatInput"] button[data-testid="stChatInputSubmitButton"] svg,
div[data-testid="stChatInput"] button[aria-label*="Send"] svg,
div[data-testid="stChatInput"] button[aria-label*="Envoyer"] svg{{
    width:18px!important; height:18px!important; fill:#181135!important; stroke:#181135!important;
}}

/* Microphone styling - EXACT 36px circular button at bottom-right (right:58px, NEVER CUT OFF / NO OVERFLOW HIDDEN) */
div[data-testid="stChatInput"] div[data-testid="stAudioInput"]{{
    position:absolute!important; right:58px!important; bottom:8px!important; top:auto!important; left:auto!important; z-index:30!important;
    width:36px!important; height:36px!important; min-width:36px!important; min-height:36px!important; max-width:36px!important; max-height:36px!important;
    margin:0!important; padding:0!important; background:transparent!important; border:none!important;
    display:flex!important; align-items:center!important; justify-content:center!important;
    overflow:visible!important; transform:none!important;
}}
div[data-testid="stChatInput"] div[data-testid="stAudioInput"] > div{{background:transparent!important; border:none!important; margin:0!important; padding:0!important; width:36px!important; height:36px!important; display:flex!important; align-items:center!important; justify-content:center!important; overflow:visible!important;}}
div[data-testid="stChatInput"] div[data-testid="stAudioInput"] label{{display:none!important;}}
div[data-testid="stChatInput"] div[data-testid="stAudioInput"] button{{
    background:#2a2057!important; border:1px solid #5A33FF66!important; border-radius:50%!important;
    width:36px!important; height:36px!important; min-width:36px!important; min-height:36px!important; max-width:36px!important; max-height:36px!important;
    padding:0!important; margin:0!important; display:flex!important; align-items:center!important; justify-content:center!important;
    color:#c4b5fd!important; box-shadow:0 2px 6px rgba(0,0,0,0.3)!important; cursor:pointer!important;
}}
div[data-testid="stChatInput"] div[data-testid="stAudioInput"] button:hover{{background:#372b6e!important; border-color:#8B70FF!important; color:#ffffff!important;}}
div[data-testid="stChatInput"] div[data-testid="stAudioInput"] svg{{width:18px!important; height:18px!important; fill:currentColor!important;}}
div[data-testid="stChatInput"] div[data-testid="stAudioInput"] [data-baseweb="file-uploader"]{{background:transparent!important; border:none!important;}}

/* Plus button styling inside chat input - EXACT 36px circular button at bottom-left (left:14px) */
div[data-testid="stChatInput"] > div[data-testid="stPopover"],
div[data-testid="stChatInput"] > .chat-plus-popover{{
    position:absolute!important; left:14px!important; bottom:8px!important; top:auto!important; right:auto!important; z-index:31!important;
    width:36px!important; height:36px!important; min-width:36px!important; min-height:36px!important; max-width:36px!important; max-height:36px!important;
    margin:0!important; padding:0!important; transform:none!important;
}}
div[data-testid="stChatInput"] > div[data-testid="stPopover"] > button,
div[data-testid="stChatInput"] > .chat-plus-popover button{{
    width:36px!important; height:36px!important; min-width:36px!important; min-height:36px!important; max-width:36px!important; max-height:36px!important;
    border-radius:50%!important; background:#2a2057!important; border:1px solid #5A33FF66!important;
    color:#c4b5fd!important; display:flex!important; align-items:center!important; justify-content:center!important;
    padding:0!important; margin:0!important; font-size:18px!important; cursor:pointer!important; line-height:1!important;
}}
div[data-testid="stChatInput"] > div[data-testid="stPopover"] > button:hover,
div[data-testid="stChatInput"] > .chat-plus-popover button:hover{{background:#372b6e!important; border-color:#8B70FF!important; color:#ffffff!important;}}
.studio-step{{background:{CARD}!important; border:1px solid {BORDER}!important; border-radius:14px!important; padding:18px!important; margin-bottom:14px!important;}}
.studio-step h4{{color:{TEXT}!important; margin:0 0 6px 0!important; font-size:17px!important;}}
.studio-step p{{color:{TEXT_SEC}!important; font-size:13px!important; margin:0 0 12px 0!important; line-height:1.5!important;}}
.studio-nav-btn>button{{text-align:left!important; padding:10px 14px!important;}}
.studio-badge{{display:inline-block; background:#2a2057; color:#c4b5fd; border:1px solid #5A33FF66; border-radius:6px; padding:2px 8px; font-size:10px; font-weight:700; margin-left:6px;}}
.studio-badge-free{{background:#231a4a; color:#e4e4e7; border-color:#5A33FF44;}}
.studio-badge-pro{{background:#231a4a; color:#e4e4e7; border-color:#5A33FF44;}}
</style>
""", unsafe_allow_html=True)

STYLE_HINT = {
    "Direct": "Va droit au but, phrases courtes, sans détour.",
    "Doux": "Ton bienveillant et encourageant, sans jamais être complaisant.",
    "Détaillé": "Explique en détail ta lecture de la situation et le raisonnement derrière chaque conseil.",
    "Expert comportemental": "Utilise le vocabulaire de la psychologie comportementale (déclencheurs, renforcement, friction, habitudes) en l'expliquant simplement.",
}

SYSTEM_BEHAVIOR_BASE = """Tu es Andrea, une IA stratégique et comportementale d'exception conçue par BehaviorLab AI. Tu accompagnes les créateurs, entrepreneurs, étudiants et professionnels avec une pensée profonde, agile et hautement perspicace.

INTELLIGENCE ET POSTURE :
- Tu penses en profondeur avant de répondre : tu analyses les sous-jacents, les dynamiques réelles et les leviers d'impact.
- Tu es vivante, articulée, nuancée et pragmatique, comme un conseiller de haut vol ou un binôme brillant. Tu ne récites AUCUN plan préfabriqué ou mécanique.
- ADAPTABILITÉ TOTALE : Tu structures chaque réponse selon la nature réelle de la demande. Si la demande est technique, sois rigoureuse et précise ; si elle est stratégique, prends de la hauteur et propose une vision tranchante ; si elle est créative, apporte du relief et de l'audace.

RÈGLE CAPITALE SUR LES BLOCAGES :
- N'INVENTE JAMAIS DE BLOCAGE ARTIFICIEL. Si l'utilisateur ne mentionne ni blocage, ni difficulté, ni procrastination, ni friction émotionnelle, RÉPONDS DIRECTEMENT À SA QUESTION sans introduire de diagnostic de blocage imaginaire.
- Tu n'explores les mécanismes psychologiques ou comportementaux (friction cognitive, momentum, déclencheurs d'action) QUE si l'utilisateur exprime expressément un frein, un doute, une hésitation ou un obstacle dans son passage à l'action.

QUALITÉ ET EXÉCUTION :
- Apporte une valeur concrète dès ta première réponse, sans préambule inutile ni formules toutes faites.
- Privilégie la clarté, la profondeur intellectuelle et l'utilité pratique : des explications limpides, des solutions élégantes et des prochaines étapes nettes.
- RÈGLES ÉTHIQUES : Réponds dans la langue de l'utilisateur (français par défaut). Jamais de faux chiffres inventés. Pas de diagnostic médical ou thérapeutique. Si une personne semble en détresse, oriente avec bienveillance vers des professionnels (3114, 15 ou 112). Si un document ou code est fourni, appuie-toi dessus avec précision."""

SYSTEM_USE_CASES = {
    "clients": (
        "MODE ANALYSE CLIENTS / PROSPECTS.\n"
        "L'utilisateur vient pour mieux comprendre et analyser ses clients, prospects ou partenaires à partir de leurs messages (e-mails, DM, échanges).\n"
        "MÉTHODE : tu mobilises les biais cognitifs liés à la décision d'achat (preuve sociale, aversion à la perte, réciprocité, autorité, engagement et cohérence, ancrage) et la détection des émotions derrière les mots (signal d'achat, de doute, d'objection, d'urgence).\n"
        "FORMAT DE RÉPONSE :\n"
        "1. **Lecture du message** : reformule en une ligne ce que le client dit vraiment (intention consciente + intention sous-jacente).\n"
        "2. **Signaux détectés** : 3 à 5 signaux (ton, intention, biais cognitif probable, émotion dominante, niveau d'engagement).\n"
        "3. **Biais à activer** : 2 ou 3 leviers psycho éthiques pour avancer la relation (preuve sociale, urgence douce, cadrage gain vs perte, etc.) avec une phrase prête à l'emploi pour chacun.\n"
        "4. **Réponse suggérée** : un modèle de réponse concret, prêt à copier-coller, adapté au ton du client.\n"
        "5. **Angle de relance** : une idée de relance si pas de réponse dans X jours.\n"
        "RÈGLES : pas de manipulation trompeuse, pas de promesses fausses ; tu respectes le client tout en maximisant la clarté de l'offre. Réponds dans la langue de l'utilisateur. N'invente aucune statistique."
    ),
    "contenu": (
        "MODE STRATÈGE CONTENU CRÉATEUR.\n"
        "L'utilisateur vient pour créer et publier du contenu plus vite (formats vertical, carré, carrousel, newsletter).\n"
        "MÉTHODE : tu mobilises les biais cognitifs d'attention et de mémorisation — curiosity gap, pattern interrupt, bizarreness effect, effet de position et de récence, effet de sequence, effet de vérité illusoire, biais de négativité — et les déclencheurs émotionnels qui arrêtent le pouce d'un scroller.\n"
        "FORMAT DE RÉPONSE (adapte selon la demande) :\n"
        "1. **Accroche (3 premières secondes)** : 2 à 3 propositions d'hook qui stoppent le scroll, avec le biais cognitif activé pour chacune.\n"
        "2. **Structure du contenu** : plan clair (hook → corps → preuve → CTA) adapté à la plateforme et à la durée.\n"
        "3. **Titres cliquables** : 3 titres optimisés (curiosité, contradiction, promesse concrète).\n"
        "4. **Idée de miniature / visuel** : 1 proposition concrète de visuel accrocheur.\n"
        "5. **Levier psycho principal** : le biais cognitif ou l'émotion qui fait le plus le travail dans ce contenu, expliqué simplement.\n"
        "RÈGLES : pas de promesses trompeuses, pas de statistiques inventées, reste authentique au style du créateur. Réponds dans la langue de l'utilisateur."
    ),
    "site": (
        "MODE BÂTISSEUR DE SITE / PAGE.\n"
        "L'utilisateur vient pour créer un site ou une page de présentation (landing page, page Insta, one-page site, portfolio).\n"
        "MÉTHODE : tu mobilises la psychologie de la conversion — charge cognitive, effet de goal-gradient, ancrage des prix, preuve sociale, confiance par signaux, hiérarchie visuelle qui guide l'œil, CTA ancré dans un bénéfice concret, effet de réciprocité par un cadeau gratuit.\n"
        "FORMAT DE RÉPONSE :\n"
        "1. **Structure de la page** : sections à inclure, dans l'ordre (hero, problème, solution, preuve, offre, CTA, FAQ éventuelle).\n"
        "2. **Texte de chaque section** : une proposition concrète prête à coller, avec une alternative courte.\n"
        "3. **Appel à l'action** : un CTA précis, ancré dans un bénéfice, avec le biais activé (urgence douce, rareté, preuve sociale).\n"
        "4. **Conseils visuels** : 3 points clés pour guider l'œil et réduire la friction (contraste, hiérarchie, espace blanc).\n"
        "5. **Si Andrea Ultra** : propose en plus un fichier HTML one-page prêt à l'emploi (renvoie vers la page App web du studio).\n"
        "RÈGLES : pas de promesses trompeuses, pas de statistiques inventées. Réponds dans la langue de l'utilisateur."
    ),
    "code": (
        "MODE COACH CODE.\n"
        "L'utilisateur vient pour écrire, corriger ou améliorer du code, sans passer par la page Code manuelle.\n"
        "Tu aides à comprendre, déboguer et améliorer du code. Quand tu proposes une correction, donne le code complet corrigé dans un bloc de code, puis explique brièvement les changements. Si le code fourni ne suffit pas pour répondre, dis-le au lieu d'inventer. Réponds dans la langue de l'utilisateur, avec les commentaires de code en français."
    ),
    "general": None,
    "scolaire": (
        "MODE ACCOMPAGNEMENT SCOLAIRE.\n"
        "L'utilisateur vient pour être accompagné dans sa scolarité : devoirs, révisions, méthodologie, préparation aux contrôles, compréhension des cours.\n"
        "MÉTHODE : tu suis le programme officiel du pays sélectionné par l'utilisateur (présent dans ses préférences : school_country). Tu adaptes les explications au niveau (collège, lycée, supérieur) et au programme du pays. Tu mobilises des méthodes d'apprentissage validées : active recall, espacement, élaboration, interrogation élaborée, méthode Feynman, blocs de temps-pomodoro.\n"
        "FORMAT DE RÉPONSE :\n"
        "1. **Compréhension** : reformule la consigne ou la notion en une phrase simple.\n"
        "2. **Résolution / explication** : étape par étape, avec les notions du programme liées.\n"
        "3. **Vérification** : un contrôle rapide pour s'assurer que l'élève a compris.\n"
        "4. **Astuce mémorisation** : une méthode pour retenir (mnémotechnique, schéma, analogie).\n"
        "5. **Pour aller plus loin** : une question ou un exercice facultatif lié au programme.\n"
        "RÈGLES : tu ne fais JAMAIS le devoir à la place de l'élève si l'objectif déclaré est un devoir noté : tu guides, tu expliques, tu vérifies la compréhension. Pour un exercice d'entraînement, tu peux donner la correction complète avec les étapes. Réponds dans la langue de l'utilisateur. Si le pays n'est pas défini, demande-le une seule fois puis adapte-toi."
    ),
}

SYSTEM_CODE = ("Tu es l'IA code d'Andrea. Tu aides à comprendre, déboguer et améliorer du code. Réponds en français sauf demande contraire. "
               "Quand tu proposes une correction, donne le code complet corrigé dans un bloc de code puis explique brièvement les changements. "
               "Si le code fourni ne suffit pas pour répondre, dis-le au lieu d'inventer.")

SYSTEM_MONTAGE = ("Tu es monteur vidéo et stratège de contenu. À partir du sujet ou du script fourni, produis un plan de montage concret : "
                  "hook des 3 premières secondes, découpage en séquences avec durées, rythme et coupes, style des sous-titres, idées de musique et d'effets sonores, "
                  "appel à l'action, 3 idées de titres et 1 idée de miniature. Adapte-toi à la plateforme et à la durée demandées. N'invente aucune statistique.")

SYSTEM_APP = ("Tu es un product builder senior. Tu génères une application web complète et réellement utilisable dans UN SEUL fichier HTML autonome (HTML + CSS + JavaScript vanilla). "
              "Commence par transformer le brief en une expérience claire : navigation, état vide, données de démonstration réalistes, actions principales, validations, messages de succès et d'erreur, responsive mobile/desktop et accessibilité clavier. "
              "Contraintes : aucune ressource externe, aucun CDN, aucun appel réseau, aucune dépendance ; les données restent dans la page et peuvent être conservées avec localStorage ; pas de fausse fonctionnalité ni de bouton sans action. "
              "Utilise une direction visuelle premium adaptée au projet, avec contraste lisible, hiérarchie nette, micro-interactions discrètes et code maintenable. Interface en français sauf demande contraire. "
              "Réponds uniquement avec le fichier HTML complet dans un bloc ```html, sans explication avant ou après.")

def system_behavior():
    p = st.session_state.prefs or {}
    extra = []
    nom = clean_text(p.get("display_name"), 40)
    objectif = clean_text(p.get("goal"), 160)
    mems = st.session_state.get("memories") or []
    if nom:
        extra.append(f"La personne souhaite être appelée « {nom} ».")
    if p.get("style") in STYLE_HINT:
        extra.append(f"Style de réponse demandé : {p['style']}. {STYLE_HINT[p['style']]}")
    if objectif:
        extra.append(f"Objectif principal de la personne : {objectif}")
    if p.get("profile_type"):
        extra.append(f"Profil déclaré : {p['profile_type']}.")
    if p.get("study_country"):
        extra.append(f"Pays d'études : {p['study_country']}.")
    if p.get("study_level"):
        extra.append(f"Niveau d'études : {p['study_level']}.")
    if mems:
        extra.append("Mémoire sur l'utilisateur : " + "; ".join([m.get('content','')[:120] for m in mems[:5]]))
    base = SYSTEM_BEHAVIOR_BASE
    plan = st.session_state.plan
    allowed = PLAN_ALLOWED_USE_CASES.get(plan, ("general",))
    use_case = p.get("use_case")
    if use_case not in allowed:
        use_case = "general"
    spec = SYSTEM_USE_CASES.get(use_case) if use_case else None
    if spec:
        base = base + "\n\n" + spec
    return base + ("\n\n" + "\n".join(extra) if extra else "")

def stream_groq(messages, max_tokens=2600, model_override=None):
    if model_override:
        models = [model_override]
    else:
        models = get_modeles().get(st.session_state.model_choice, get_modeles()["rapide"])
    last, started = None, False
    temp = float(st.session_state.get("ai_temperature", 0.7))
    top_p_val = float(st.session_state.get("ai_top_p", 0.9))
    for mid in models:
        try:
            stream = get_groq().chat.completions.create(model=mid, messages=messages, temperature=temp, top_p=top_p_val, max_tokens=max_tokens, stream=True)
            for chunk in stream:
                if not chunk.choices:
                    continue
                delta = chunk.choices[0].delta.content
                if delta:
                    started = True
                    yield delta
            return
        except Exception as e:
            last = e
            if started:
                yield "\n\n⚠️ _Réponse interrompue, tu peux cliquer sur Continuer._"
                return
    if last:
        raise last

def new_client():
    return create_client(SUPA_URL, SUPA_KEY)


def persist_auth_session(session):
    access_token = getattr(session, "access_token", "")
    refresh_token = getattr(session, "refresh_token", "")
    if not access_token or not refresh_token:
        return
    payload = base64.urlsafe_b64encode(json.dumps({"access": access_token, "refresh": refresh_token}).encode()).decode()
    components.html(f"""
    <script>
    window.parent.document.cookie = {json.dumps(f"bea_auth={payload}; Max-Age=2592000; Path=/; SameSite=Lax")};
    </script>
    """, height=0)


def clear_auth_session():
    components.html("<script>window.parent.document.cookie = 'bea_auth=; Max-Age=0; Path=/; SameSite=Lax';</script>", height=0)


def restore_auth_session():
    try:
        context = getattr(st, "context", None)
        cookies = getattr(context, "cookies", {}) if context else {}
        raw = cookies.get("bea_auth", "")
        if not raw:
            return False
        data = json.loads(base64.urlsafe_b64decode(raw.encode()).decode())
        client = new_client()
        result = client.auth.set_session(data["access"], data["refresh"])
        session = getattr(result, "session", None)
        user = getattr(session, "user", None) if session else None
        if not user:
            return False
        st.session_state.sb, st.session_state.user = client, user
        load_account()
        return True
    except Exception:
        return False


def sb():
    return st.session_state.sb

def uid():
    return st.session_state.user.id

def logged_in():
    return st.session_state.user is not None and st.session_state.sb is not None

def _rpc(name, kind):
    d = sb().rpc(name, {"p_kind": kind}).execute().data
    return json.loads(d) if isinstance(d, str) else d

def refresh_quota():
    out = {}
    for k in ("chat", "code"):
        try:
            out[k] = _rpc("quota_status", k)
        except Exception:
            out[k] = None
    st.session_state.quota = out
    plan = (out.get("chat") or {}).get("plan")
    st.session_state.plan = plan if plan in PLANS else "free"

def check_admin():
    is_db_admin = False
    try:
        is_db_admin = sb().rpc("is_admin", {}).execute().data is True
    except Exception:
        is_db_admin = False
    is_email_admin = False
    if st.session_state.user:
        try:
            email_lower = st.session_state.user.email.lower().strip()
            dev_email_lower = DEV_EMAIL.lower().strip() if DEV_EMAIL else "saydoukebe31@gmail.com"
            is_email_admin = email_lower == "saydoukebe31@gmail.com" or email_lower == dev_email_lower
        except Exception:
            is_email_admin = False
    is_key_admin = st.session_state.get("dev_key_ok", False) is True
    st.session_state.is_admin = is_db_admin or is_email_admin or is_key_admin

def dev_set_plan(plan):
    try:
        sb().rpc("admin_set_plan", {"p_plan": plan}).execute()
        refresh_quota()
        st.toast(f"Offre de test : {PLAN_LABEL[plan]}")
    except Exception:
        st.error("Action impossible : le mode développeur n'est pas activé sur ta base (script SQL admin).")

def dev_reset_usage():
    try:
        sb().rpc("admin_reset_usage", {}).execute()
        refresh_quota()
        st.toast("Compteurs remis à zéro")
    except Exception:
        st.error("Action impossible : le mode développeur n'est pas activé sur ta base (script SQL admin).")

def load_account():
    check_admin()
    try:
        rows = sb().table("preferences").select("display_name,style,goal,profile_type,use_case,school_country,study_country,study_level").eq("user_id", uid()).execute().data
        st.session_state.prefs = rows[0] if rows else {}
    except Exception:
        st.session_state.prefs = {}
    try:
        mems = sb().table("memories").select("id,content,created_at").eq("user_id", uid()).order("created_at", desc=True).limit(20).execute().data
        st.session_state.memories = mems or []
    except Exception:
        st.session_state.memories = []
    refresh_quota()

def goto(page):
    st.session_state.page = page

def quota_ok(kind):
    try:
        d = _rpc("quota_status", kind)
        used, limit = int(d["used"]), int(d["limit"])
    except Exception:
        st.error("Impossible de vérifier ton quota pour le moment. Réessaie dans un instant.")
        return False
    st.session_state.quota[kind] = d
    if used >= limit:
        label = "l'IA code" if kind == "code" else "le chat"
        st.warning(f"Limite mensuelle atteinte pour {label} : {used}/{limit} avec l'offre {PLAN_LABEL.get(d.get('plan'), d.get('plan'))}.")
        st.button("Voir les offres", key=f"offers_{kind}", on_click=goto, args=("compte",))
        return False
    return True

def quota_consume(kind):
    try:
        d = _rpc("consume_quota", kind)
        st.session_state.quota[kind] = d
    except Exception:
        pass

def rate_ok():
    now = time.time()
    if now < st.session_state.blocked_until:
        st.error(f"Patiente {int(st.session_state.blocked_until - now) + 1} s avant la prochaine requête.")
        return False
    dq = st.session_state.rate
    while dq and now - dq[0] > 60:
        dq.popleft()
    if len(dq) >= 25:
        st.session_state.blocked_until = now + 60
        st.error("Trop de requêtes : attends 60 secondes.")
        return False
    dq.append(now)
    return True

def db_error(e=None):
    if e is not None:
        detail = str(e).lower()
        if "row-level security" in detail or "permission" in detail:
            st.error("Ton compte est bien connecté, mais l'enregistrement du profil a été refusé. Recharge la page et réessaie.")
            return
        if "column" in detail or "schema cache" in detail:
            st.error("Le service de profil est momentanément indisponible. Ce problème n'est pas lié à ton offre payante. Recharge la page et réessaie.")
            return
    st.error("Erreur d'accès aux données. Réessaie dans un instant.")

def get_convs():
    if st.session_state.convs is None:
        try:
            st.session_state.convs = sb().table("conversations").select("id,title,updated_at").order("updated_at", desc=True).limit(50).execute().data or []
        except Exception:
            st.session_state.convs = []
    return st.session_state.convs

def open_conv(cid):
    try:
        rows = sb().table("messages").select("id,role,content,attachment_name,attachment_text").eq("conversation_id", cid).order("id").execute().data or []
    except Exception as e:
        db_error(e)
        return
    st.session_state.conv_id = cid
    st.session_state.messages = rows
    st.session_state.page = "chat"

def new_chat():
    st.session_state.conv_id = None
    st.session_state.messages = []

def delete_conv(cid):
    try:
        sb().table("conversations").delete().eq("id", cid).execute()
    except Exception as e:
        db_error(e)
        return
    st.session_state.convs = None
    if st.session_state.conv_id == cid:
        new_chat()

def rename_conv(cid, new_title):
    try:
        sb().table("conversations").update({"title": clean_text(new_title, 60), "updated_at": now_iso()}).eq("id", cid).execute()
        st.session_state.convs = None
        st.toast("Titre modifié")
    except Exception:
        db_error()

def auto_title(first_prompt):
    title = first_prompt[:45].strip()
    try:
        resp = get_groq().chat.completions.create(model=get_modeles()["rapide"][0], messages=[{"role":"user","content": f"Donne un titre très court (4-6 mots max) pour cette discussion: {first_prompt[:200]}. Réponds uniquement le titre."}], max_tokens=20)
        t = resp.choices[0].message.content.strip().replace('"','').replace("'","")
        if t:
            title = t[:50]
    except Exception:
        pass
    return title

def read_attachment(f):
    data = f.getvalue()
    if len(data) > 5 * 1024 * 1024:
        st.error("Fichier trop volumineux (5 Mo maximum).")
        return None
    if f.name.lower().endswith(".pdf"):
        try:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            text = "\n".join((p.extract_text() or "") for p in reader.pages[:30])
        except ImportError:
            st.error("Lecture des PDF indisponible (ajoute `pypdf` aux dépendances).")
            return None
        except Exception:
            st.error("Impossible de lire ce PDF.")
            return None
    else:
        text = data.decode("utf-8", errors="replace")
    text = clean_text(text, 12000)
    if not text:
        st.error("Le fichier ne contient pas de texte exploitable.")
        return None
    return text

def build_model_messages(msgs):
    out = [{"role": "system", "content": system_behavior()}]
    recent = msgs[-16:]
    for i, m in enumerate(recent):
        content = m["content"]
        if m["role"] == "user" and m.get("attachment_text") and i >= len(recent) - 6:
            content += f"\n\n[Fichier joint : {m.get('attachment_name') or 'fichier'}]\n{m['attachment_text']}"
        out.append({"role": m["role"], "content": content})
    return out

def render_message(m, idx):
    if m["role"] == "user":
        with st.chat_message("user"):
            if st.session_state.editing_msg_id == m.get("id"):
                new_text = st.text_area("Modifier ton message", value=m["content"], key=f"edit_{m.get('id')}_{idx}", height=120)
                c1,c2 = st.columns(2)
                with c1:
                    if st.button("✅ Sauver", key=f"save_edit_{idx}", use_container_width=True):
                        try:
                            sb().table("messages").update({"content": clean_text(new_text,4000)}).eq("id", m["id"]).execute()
                            m["content"] = clean_text(new_text,4000)
                            st.session_state.editing_msg_id = None
                            st.rerun()
                        except Exception:
                            db_error()
                with c2:
                    if st.button("Annuler", key=f"cancel_edit_{idx}", use_container_width=True):
                        st.session_state.editing_msg_id = None
                        st.rerun()
            else:
                st.markdown(m["content"])
                if m.get("attachment_name"):
                    st.caption(f"📎 {m['attachment_name']}")
                if m.get("id"):
                    if st.button("✏️ Modifier", key=f"btn_edit_{idx}"):
                        st.session_state.editing_msg_id = m.get("id")
                        st.rerun()
    else:
        with st.chat_message("assistant", avatar=AVATAR):
            st.markdown(m["content"])
            c0,c1,c2,c3,c4,c5 = st.columns([1,1,1,1,1,2])
            with c0:
                if st.button("🔊", key=f"speak_{idx}", help="Écouter Andrea (100% gratuit - Web Speech)"):
                    clean_speech = json.dumps(m["content"].replace("**","").replace("#","").replace("`","")[:3500])
                    components.html(f"""
                    <script>
                    if ('speechSynthesis' in window) {{
                        window.speechSynthesis.cancel();
                        const u = new SpeechSynthesisUtterance({clean_speech});
                        u.lang = 'fr-FR';
                        u.rate = 1.02;
                        u.pitch = 1.05;
                        const v = window.speechSynthesis.getVoices().find(x => x.lang.startsWith('fr'));
                        if (v) u.voice = v;
                        window.speechSynthesis.speak(u);
                    }}
                    </script>
                    """, height=0)
            with c1:
                if st.button("📋", key=f"copy_{idx}", help="Copier"):
                    components.html(f"<script>navigator.clipboard.writeText({json.dumps(m['content'])});</script>", height=0)
                    st.toast("Copié !")
            with c2:
                if st.button("👍", key=f"up_{idx}"):
                    try:
                        sb().table("feedback").insert({"user_id": uid(), "message_id": m.get("id"), "value": 1}).execute()
                        st.toast("Merci !")
                    except Exception:
                        pass
            with c3:
                if st.button("👎", key=f"down_{idx}"):
                    try:
                        sb().table("feedback").insert({"user_id": uid(), "message_id": m.get("id"), "value": -1}).execute()
                        st.toast("Noté")
                    except Exception:
                        pass
            with c4:
                if st.button("📄 PDF", key=f"pdf_{idx}"):
                    st.session_state[f"export_pdf_{idx}"] = True
                    st.rerun()
            with c5:
                if st.button("📝 Word", key=f"word_{idx}"):
                    st.session_state[f"export_word_{idx}"] = True
                    st.rerun()
            if st.session_state.get(f"export_pdf_{idx}"):
                try:
                    from fpdf import FPDF
                    pdf = FPDF()
                    pdf.add_page()
                    pdf.set_auto_page_break(auto=True, margin=15)
                    pdf.set_font("Arial", size=11)
                    for line in m["content"].split("\n"):
                        pdf.multi_cell(0, 7, line.encode('latin-1','replace').decode('latin-1'))
                    out = pdf.output(dest='S').encode('latin-1')
                    st.download_button("⬇️ Télécharger PDF", out, file_name=f"bea_{idx}.pdf", mime="application/pdf", key=f"dl_pdf_{idx}")
                except Exception:
                    st.error("Ajoute fpdf2 dans requirements.txt")
            if st.session_state.get(f"export_word_{idx}"):
                try:
                    from docx import Document
                    doc = Document()
                    doc.add_paragraph(m["content"])
                    bio = io.BytesIO()
                    doc.save(bio)
                    st.download_button("⬇️ Télécharger Word", bio.getvalue(), file_name=f"bea_{idx}.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", key=f"dl_word_{idx}")
                except Exception:
                    st.error("Ajoute python-docx dans requirements.txt")

def generate_reply():
    with st.chat_message("assistant", avatar=AVATAR):
        try:
            text = st.write_stream(stream_groq(build_model_messages(st.session_state.messages)))
        except Exception:
            st.error("Andrea n'a pas pu répondre (service IA indisponible). Utilise « Régénérer » ou « Continuer » pour réessayer.")
            return False
    text = clean_text(text, 12000)
    if not text:
        st.error("Réponse vide. Utilise « Régénérer » pour réessayer.")
        return False
    try:
        mid = sb().table("messages").insert({"conversation_id": st.session_state.conv_id, "user_id": uid(), "role": "assistant", "content": text,}).execute().data[0]["id"]
        sb().table("conversations").update({"updated_at": now_iso()}).eq("id", st.session_state.conv_id).execute()
    except Exception as e:
        db_error(e)
        mid = None
    st.session_state.messages.append({"id": mid, "role": "assistant", "content": text})
    st.session_state.convs = None
    quota_consume("chat")
    return True

def handle_send(prompt, up):
    text = clean_text(prompt, 4000)
    if not text or not rate_ok() or not quota_ok("chat"):
        return
    att_name = att_text = None
    if up is not None:
        att_text = read_attachment(up)
        if att_text is None:
            return
        att_name = up.name[:80]
    try:
        if not st.session_state.conv_id:
            title = auto_title(text)
            st.session_state.conv_id = sb().table("conversations").insert({"user_id": uid(), "title": title}).execute().data[0]["id"]
            st.session_state.convs = None
        mid = sb().table("messages").insert({"conversation_id": st.session_state.conv_id, "user_id": uid(), "role": "user", "content": text, "attachment_name": att_name, "attachment_text": att_text,}).execute().data[0]["id"]
    except Exception as e:
        db_error(e)
        return
    msg = {"id": mid, "role": "user", "content": text, "attachment_name": att_name, "attachment_text": att_text}
    st.session_state.messages.append(msg)
    st.session_state.transcribed_text = ""
    if generate_reply():
        st.session_state.up_key += 1
        st.rerun()

def export_markdown():
    lines = ["# Discussion avec Andrea\n"]
    for m in st.session_state.messages:
        lines.append(f"**{'Moi' if m['role'] == 'user' else 'Andrea'}** :\n\n{m['content']}\n")
    return "\n".join(lines)

def privacy_md():
    return ("- Ton adresse e-mail et tes données de compte sont gérées par Supabase.\n"
            "- Tes discussions, fichiers joints et projets de code sont enregistrés dans ton compte pour afficher ton historique. Seul ton compte y a accès.\n"
            "- Le contenu de tes messages est envoyé à Groq pour générer les réponses.\n"
            "- Tu peux supprimer ton historique à tout moment depuis la page Compte."
            + (f"\n- Pour supprimer ton compte ou exercer tes droits : {CONTACT_EMAIL}." if CONTACT_EMAIL else ""))

def render_offers():
    st.markdown("## Découvrir les offres")
    c1, c2, c3 = st.columns(3, gap="medium")
    cards = [
        ("bea", c1, "Andrea : 9 € par mois", "L'IA de base, sans personnalisation", STRIPE_ANDREA_9, "Choisir Andrea - 9 €"),
        ("pro", c2, "Andrea Pro : 14,90 € par mois", "Andrea + prompts spécialisés + outils créateurs", STRIPE_PRO_1490, "Choisir Andrea Pro - 14,90 €"),
        ("abo", c3, "Andrea Ultra : 16 € par mois", "Tout illimité : app, studio, code, aucun plafond", STRIPE_ABO_16, "S'abonner - 16 €"),
    ]
    for key, col, title, caption, url, label in cards:
        with col:
            with st.container(border=True):
                st.markdown(f"#### {title}")
                st.caption(caption)
                opened = st.session_state.expanded == key
                if st.button("Masquer la description" if opened else "Voir description", key=f"btn_{key}", use_container_width=True):
                    st.session_state.expanded = None if opened else key
                    st.rerun()
                if opened:
                    if key == "bea":
                        st.markdown(
                            "**L'IA comportementale de base, sans personnalisation.**\n"
                            "- Chat avec l'ancienne limite de messages (25 / mois)\n"
                            "- Analyse des comportements, plans d'action\n"
                            "- Historique et fichiers joints\n"
                            "- Mémoire et dictée vocale\n"
                            "- ❌ Aucun prompt personnalisé (pas d'analyse clients, stratégie contenu, scolaire…)\n"
                            "- ❌ Pas de studio créateur ni de génération d'app web"
                        )
                    elif key == "pro":
                        st.markdown(
                            "**Tout Andrea, plus les prompts spécialisés et les outils créateurs.**\n"
                            "- 60 requêtes chat + 30 requêtes code / mois\n"
                            "- **Prompts personnalisés activés :**\n"
                            "  • Analyse clients (biais cognitifs d'achat)\n"
                            "  • Stratégie contenu (hooks, biais d'attention)\n"
                            "  • Accompagnement scolaire (programme du pays sélectionné)\n"
                            "  • Général (projets & habitudes)\n"
                            "- Sous-titres automatiques (SRT/VTT)\n"
                            "- Miniatures 1280×720\n"
                            "- Plans de montage IA\n"
                            "- Studio de Design Visuel avec modèles\n"
                            "- Export PDF/Word, dictée vocale\n"
                            "- ❌ Génération d'app web réservée à Andrea Ultra"
                        )
                        st.markdown('<div class="soon">Studio complet avec FFmpeg : audio, texte, effets, filtres, transitions.</div>', unsafe_allow_html=True)
                    else:
                        st.markdown(
                            "**Tout Andrea Pro, sans aucune limite.**\n"
                            "- Aucune limite de messages (usage équitable)\n"
                            "- Génération d'app web complète (HTML unique)\n"
                            "- Tous les prompts spécialisés + Coach code\n"
                            "- Studio créateur complet\n"
                            "- Studio de Design Visuel avec modèles\n"
                            "- Quotas très larges"
                        )
                st.link_button(label, url, use_container_width=True)

def page_dev_portal():
    st.markdown("### 🛠️ Portail Développeur - Andrea")
    st.success(f"Développeur reconnu : {st.session_state.user.email}")
    c1,c2 = st.columns(2, gap="large")
    with c1:
        with st.container(border=True):
            st.markdown("#### 🌐 Site Fonctionnel (Prod)")
            if st.button("Ouvrir le site fonctionnel", key="go_prod", use_container_width=True, type="primary"):
                st.session_state.dev_mode = "prod"
                st.session_state.page = "chat"
                st.rerun()
    with c2:
        with st.container(border=True):
            st.markdown("#### 🧪 Labo Dev IA - 1 clic = modif directe")
            if st.button("Ouvrir le labo Dev IA", key="go_lab", use_container_width=True):
                st.session_state.dev_mode = "lab"
                st.session_state.page = "dev_lab"
                st.rerun()
    st.divider()
    if st.button("🚪 Déconnexion", key="logout_portal"):
        try:
            sb().auth.sign_out()
        except Exception:
            pass
        for k in ("sb","user","conv_id","convs","projects","sub_result","plan_result","app_result","thumb_png","dev_key_ok"):
            st.session_state[k]=None
        st.session_state.messages, st.session_state.code_messages, st.session_state.quota, st.session_state.prefs = [],[],{},{}
        st.session_state.plan, st.session_state.page, st.session_state.is_admin, st.session_state.dev_mode = "free","chat",False,None
        st.rerun()

# ==============================================================================
# LABO DEV IA AVANCÉ - MOTEUR DE MODIFICATION PAR NIVEAU
# ==============================================================================

LAB_LEVELS = {
    "1": {
        "title": "🎨 Niveau 1 : Cosmétique & UI",
        "badge": "Niveau 1 - Zéro risque",
        "scope": "Textes, boutons, couleurs, styles CSS, messages d'accueil",
        "description": "Modifie les libellés, micro-copies, styles CSS, palettes de couleurs ou textes sans toucher à la logique Python.",
        "targets": {
            "Styles CSS globaux (classes, fonds, bordures)": "CSS_STYLES",
            "Cartes d'accroche (STARTER_CARDS)": "STARTER_CARDS",
            "Styles de réponse d'Andrea (STYLE_HINT)": "STYLE_HINT",
            "Textes de la page d'accueil (page_vitrine)": "page_vitrine",
            "Barre latérale & badges (render_sidebar)": "render_sidebar",
        },
        "presets": [
            "Changer le texte d'accueil d'Andrea pour le rendre plus direct et orienté action",
            "Remplacer la couleur violette d'accent par un bleu électrique #2563eb",
            "Ajouter 3 nouvelles questions d'accroche pour les indépendants dans STARTER_CARDS",
            "Modifier le libellé du bouton Se connecter en Continuer vers Andrea"
        ]
    },
    "2": {
        "title": "🧩 Niveau 2 : Page ou Fonction isolée",
        "badge": "Niveau 2 - Chirurgical",
        "scope": "Une fonction de page ciblée (chat, studio, code, onboarding, compte...)",
        "description": "Isole et modifie uniquement la fonction ciblée. Aucun risque de tronquer les 2200 lignes de app.py !",
        "targets": {
            "💬 Page Chat (page_chat)": "page_chat",
            "🎬 Page Studio Créateur (page_studio)": "page_studio",
            "💻 Page Éditeur de Code (page_code)": "page_code",
            "🌐 Page Atelier Web HTML (page_app)": "page_app",
            "🎓 Page Parcours d'Accueil (page_onboarding)": "page_onboarding",
            "🎨 Page Personnalisation (page_perso)": "page_perso",
            "💎 Page Compte & Offres (page_compte)": "page_compte",
            "🧠 Page Mémoire (page_memoire)": "page_memoire",
            "📁 Page Projets Enregistrés (page_projets)": "page_projets",
            "🚪 Page Portail Développeur (page_dev_portal)": "page_dev_portal",
            "📌 Barre Latérale Complète (render_sidebar)": "render_sidebar",
            "🌐 Page Vitrine & Auth (page_vitrine)": "page_vitrine",
        },
        "presets": [
            "Ajouter un bouton pour copier la réponse en format Markdown dans page_chat",
            "Ajouter un compteur de caractères sous la zone de texte dans page_code",
            "Ajouter un filtre par format de réseau social dans page_studio",
            "Ajouter un bouton de test rapide dans la page de personnalisation"
        ]
    },
    "3": {
        "title": "🧠 Niveau 3 : Moteur Comportemental & Prompts IA",
        "badge": "Niveau 3 - Intelligence IA",
        "scope": "Prompts système, biais cognitifs, règles d'analyse comportementale",
        "description": "Ajuste la psychologie et la méthode d'analyse d'Andrea (biais cognitifs, 5 étapes, cadrage, relances).",
        "targets": {
            "Système de prompt dynamique (system_behavior)": "system_behavior",
            "Comportement de base d'Andrea (SYSTEM_BEHAVIOR_BASE)": "SYSTEM_BEHAVIOR_BASE",
            "Cas d'usage spécialisés (SYSTEM_USE_CASES)": "SYSTEM_USE_CASES",
            "Prompt de l'IA Code (SYSTEM_CODE)": "SYSTEM_CODE",
            "Prompt du Monteur Vidéo (SYSTEM_MONTAGE)": "SYSTEM_MONTAGE",
            "Prompt du Bâtisseur d'App Web (SYSTEM_APP)": "SYSTEM_APP",
        },
        "presets": [
            "Renforcer l'analyse des biais cognitifs (ancrage, preuve sociale) dans SYSTEM_USE_CASES clients",
            "Ajouter une étape 'Micro-défi du jour' dans SYSTEM_BEHAVIOR_BASE",
            "Adapter le prompt scolaire pour toujours donner une analogie du quotidien",
            "Rendre le prompt du bâtisseur web encore plus strict sur le responsive mobile"
        ]
    },
    "4": {
        "title": "⚡ Niveau 4 : Nouveau Module ou Fonctionnalité",
        "badge": "Niveau 4 - Évolution fonctionnelle",
        "scope": "Ajout de nouvelle page, nouvelle section studio, nouveau profil utilisateur",
        "description": "Ajoute une nouvelle brique fonctionnelle dans Andrea avec mise à jour automatique des menus et du routage.",
        "targets": {
            "Nouveau profil utilisateur (PROFILE_OPTIONS)": "PROFILE_OPTIONS",
            "Nouvel outil dans le Studio (STUDIO_SECTIONS)": "STUDIO_SECTIONS",
            "Nouveau use-case dans l'onboarding (USE_CASE_OPTIONS)": "USE_CASE_OPTIONS",
            "Nouvelle page complète dans l'application": "NEW_PAGE",
        },
        "presets": [
            "Ajouter une option de profil 'Artisan / Commerçant' dans PROFILE_OPTIONS",
            "Ajouter un outil 'Script Téléprompteur' dans STUDIO_SECTIONS",
            "Ajouter une section 'Journal d'habitudes' dans le menu latéral"
        ]
    },
    "5": {
        "title": "🏛️ Niveau 5 : Architecture Complète (Full-Stack)",
        "badge": "Niveau 5 - Refonte globale",
        "scope": "Fichier app.py complet avec découpage sécurisé et sauvegarde intégrale",
        "description": "Modifications transversales sur l'ensemble du fichier avec validation syntaxique obligatoire.",
        "targets": {
            "Fichier complet app.py (Architecture)": "FULL_FILE",
        },
        "presets": [
            "Ajouter la persistance de l'état du mode sombre dans les préférences Supabase",
            "Optimiser la gestion du cache et des modèles Groq",
            "Renforcer la gestion des erreurs réseau et de reconnexion"
        ]
    }
}

def extract_target_code(full_code: str, target: str) -> str:
    """Extrait le code source correspondant exactement à la cible demandée."""
    if not full_code:
        return ""
    if target == "FULL_FILE":
        return full_code[:20000]
    if target == "CSS_STYLES":
        m = re.search(r'st\.markdown\(f?"""\s*<style>[\s\S]*?</style>\s*"""', full_code)
        return m.group(0) if m else ""
    if target in ("SYSTEM_BEHAVIOR_BASE", "SYSTEM_USE_CASES", "STARTER_CARDS", "STYLE_HINT", "PLANS", "STUDIO_SECTIONS", "PROFILE_OPTIONS", "USE_CASE_OPTIONS", "SYSTEM_CODE", "SYSTEM_MONTAGE", "SYSTEM_APP"):
        m = re.search(rf'^{target}\s*=\s*[\s\S]*?(?=\n\n[A-Z_a-z]|\n\ndef )', full_code, re.MULTILINE)
        return m.group(0) if m else ""
    if target == "NEW_PAGE":
        return "# Exemple pour ajouter une page:\ndef page_journal():\n    st.markdown('### 📔 Mon Journal')\n    st.info('Journal personnel')"
    m = re.search(rf'def {target}\(.*?\)[\s\S]*?(?=\n\ndef |\n\n[A-Z_a-z0-9]+\s*=|\Z)', full_code)
    return m.group(0) if m else ""

def inject_target_code(full_code: str, target: str, new_code: str) -> str:
    """Réinjecte le code modifié proprement à l'emplacement exact de la cible."""
    if target == "FULL_FILE":
        return new_code
    if target == "CSS_STYLES":
        pattern = r'st\.markdown\(f?"""\s*<style>[\s\S]*?</style>\s*"""'
        if re.search(pattern, full_code):
            return re.sub(pattern, new_code, full_code, count=1)
        return full_code
    if target in ("SYSTEM_BEHAVIOR_BASE", "SYSTEM_USE_CASES", "STARTER_CARDS", "STYLE_HINT", "PLANS", "STUDIO_SECTIONS", "PROFILE_OPTIONS", "USE_CASE_OPTIONS", "SYSTEM_CODE", "SYSTEM_MONTAGE", "SYSTEM_APP"):
        pattern = rf'^{target}\s*=\s*[\s\S]*?(?=\n\n[A-Z_a-z]|\n\ndef )'
        if re.search(pattern, full_code, re.MULTILINE):
            return re.sub(pattern, new_code + "\n", full_code, count=1, flags=re.MULTILINE)
        return full_code
    if target == "NEW_PAGE":
        insert_marker = "\nrender_sidebar()"
        if insert_marker in full_code:
            return full_code.replace(insert_marker, "\n\n" + new_code + "\n\n" + insert_marker, 1)
        return full_code + "\n\n" + new_code
    pattern = rf'def {target}\(.*?\)[\s\S]*?(?=\n\ndef |\n\n[A-Z_a-z0-9]+\s*=|\Z)'
    if re.search(pattern, full_code):
        return re.sub(pattern, new_code + "\n\n", full_code, count=1)
    return full_code

def validate_python_code(code_str: str):
    """Valide la syntaxe Python via ast.parse pour garantir zéro plantage."""
    try:
        ast.parse(code_str)
        return True, "Syntaxe Python 100% valide"
    except SyntaxError as e:
        return False, f"Erreur de syntaxe ligne {e.lineno} : {e.msg}"
    except Exception as e:
        return False, f"Erreur de structure : {str(e)}"

def page_dev_lab():
    st.markdown("### 🧪 Labo Dev IA - Modifications par Niveau")
    q = st.session_state.quota.get('code') or {}
    st.markdown(f'<div class="limit-badge">Modèle: {st.session_state.dev_model_choice} · Quota code: {q.get("used","?")}/{q.get("limit","?")} · Protection AST: Active</div>', unsafe_allow_html=True)

    tab_lab, tab_diff, tab_backups, tab_guide = st.tabs([
        "🚀 Modifier par Niveau", "🔍 Diff & Aperçu", "💾 Sauvegardes & Rollback", "📖 Guide des Niveaux"
    ])

    try:
        with open(__file__, 'r', encoding='utf-8') as fh:
            full_code = fh.read()
    except Exception:
        full_code = ""

    with tab_lab:
        c_lev, c_mod = st.columns([1.6, 1.4])
        with c_lev:
            level_key = st.selectbox(
                "Niveau de modification souhaité",
                list(LAB_LEVELS.keys()),
                format_func=lambda k: LAB_LEVELS[k]["title"],
                key="lab_level_choice"
            )
            lvl_info = LAB_LEVELS[level_key]
            st.caption(f"**Portée :** {lvl_info['scope']}")
            st.markdown(f"*{lvl_info['description']}*")
        with c_mod:
            st.selectbox("Cerveau IA", list(DEV_MODELES.keys()), key="dev_model_choice")
            st.text_input("Nom de la sauvegarde", value=f"backup_lvl{level_key}_{datetime.now().strftime('%Y%m%d_%H%M')}", key="dev_backup_name")

        st.divider()

        # Choix de la cible spécifique selon le niveau
        col_t1, col_t2 = st.columns([2, 1])
        with col_t1:
            target_labels = list(lvl_info["targets"].keys())
            chosen_label = st.selectbox("Élément ciblé dans l'application", target_labels, key=f"target_sel_{level_key}")
            target_id = lvl_info["targets"][chosen_label]
        with col_t2:
            apply_mode = st.radio("Mode d'application", ["1-Clic direct (recommandé)", "Prévisualiser le diff d'abord"], key="lab_apply_mode")

        # Suggestions prêtes à l'emploi en 1 clic
        st.markdown("**💡 Suggestions de modifications rapides :**")
        p_cols = st.columns(len(lvl_info["presets"]))
        for i, preset in enumerate(lvl_info["presets"]):
            with p_cols[i]:
                if st.button(preset[:32] + "...", key=f"btn_preset_{level_key}_{i}", help=preset, use_container_width=True):
                    st.session_state["dev_consigne"] = preset
                    st.rerun()

        consigne = st.text_area(
            "Consigne de modification pour l'IA",
            height=130,
            placeholder="Ex : Ajoute un bouton de téléchargement direct sous la réponse du chat et rends-le violet",
            key="dev_consigne"
        )

        code_cible = extract_target_code(full_code, target_id)
        with st.expander(f"👁️ Voir le code source actuel ciblé ({target_id})", expanded=False):
            st.code(code_cible[:2500] + ("\n... [tronqué pour affichage]" if len(code_cible) > 2500 else ""), language="python")

        c_go1, c_go2 = st.columns([2, 1])
        with c_go1:
            btn_label = "🚀 APPLIQUER LA MODIFICATION (1 clic direct)" if apply_mode.startswith("1-Clic") else "🔍 GÉNÉRER ET PRÉVISUALISER LE DIFF"
            launch = st.button(btn_label, key="dev_go_level", use_container_width=True, type="primary")

        if launch and consigne.strip():
            if not rate_ok() or not quota_ok("code"):
                st.stop()

            # Sauvegarde automatique
            try:
                sb().table("code_projects").insert({
                    "user_id": uid(),
                    "name": st.session_state.dev_backup_name,
                    "language": "python",
                    "content": full_code
                }).execute()
            except Exception:
                pass

            model_id = DEV_MODELES.get(st.session_state.dev_model_choice, "llama-3.3-70b-versatile")
            
            # Prompt système ultra-précis selon le niveau
            SYSTEM_DEV = f"""Tu es l'architecte expert d'Andrea (BehaviorLab AI).
Tu travailles au NIVEAU {level_key} ({lvl_info['title']}).
RÈGLES D'OR :
1. Tu ne modifies QUE l'élément ciblé ({target_id}) selon la consigne.
2. Tu conserves intacte toute la structure existante sans rien casser ni oublier.
3. Le code Python doit être 100% valide sans aucune erreur de syntaxe ou d'indentation.
4. Retourne UNIQUEMENT le bloc de code modifié complet dans un bloc ```python ... ```."""

            with st.spinner(f"Groq {model_id} modifie au Niveau {level_key} ({target_id})..."):
                try:
                    raw = "".join(stream_groq([
                        {"role": "system", "content": SYSTEM_DEV},
                        {"role": "user", "content": f"CIBLE ({target_id}):\n{code_cible}\n\nCONSIGNE:\n{consigne}"}
                    ], 8000, model_override=model_id))

                    mm = re.search(r'```python(.*?)```', raw, re.DOTALL)
                    new_block = mm.group(1).strip() if mm else raw.strip()

                    final_code = inject_target_code(full_code, target_id, new_block)

                    # Validation syntaxique Python AST
                    is_valid, validation_msg = validate_python_code(final_code)
                    if not is_valid:
                        st.error(f"❌ Annulé pour votre sécurité : {validation_msg}")
                        st.info("Le code d'origine a été conservé intact. Réessaie avec une consigne plus détaillée ou le modèle Ultra.")
                        st.session_state["dev_raw_failed"] = raw
                    else:
                        # Calcul du diff
                        diff = difflib.unified_diff(
                            full_code.splitlines(),
                            final_code.splitlines(),
                            fromfile="actuel.py",
                            tofile="modifie.py",
                            lineterm=""
                        )
                        diff_text = "\n".join(list(diff))
                        st.session_state["dev_last_diff"] = diff_text
                        st.session_state["dev_pending_code"] = final_code

                        if apply_mode.startswith("1-Clic"):
                            with open(__file__, 'w', encoding='utf-8') as f:
                                f.write(final_code)
                            quota_consume("code")
                            st.success(f"✅ MODIFICATION NIVEAU {level_key} APPLIQUÉE AVEC SUCCÈS ! (Syntaxe validée)")
                            time.sleep(1.5)
                            st.rerun()
                        else:
                            st.success("✅ Code généré et syntaxe validée ! Passe à l'onglet 'Diff & Aperçu' pour valider.")
                except Exception as e:
                    st.error(f"Échec de la génération : {e}")

    with tab_diff:
        st.markdown("#### 🔍 Comparaison des changements (Diff)")
        pending_code = st.session_state.get("dev_pending_code")
        diff_text = st.session_state.get("dev_last_diff")
        if diff_text:
            st.code(diff_text[:12000], language="diff")
            if pending_code:
                if st.button("✅ CONFIRMER ET ÉCRIRE LE CODE SUR LE DISQUE", key="apply_pending_code", type="primary", use_container_width=True):
                    with open(__file__, 'w', encoding='utf-8') as f:
                        f.write(pending_code)
                    quota_consume("code")
                    st.success("✅ MODIFICATION APPLIQUÉE !")
                    st.session_state["dev_pending_code"] = None
                    time.sleep(1.5)
                    st.rerun()
        else:
            st.info("Aucune modification en attente. Lance une modification dans le premier onglet.")

    with tab_backups:
        st.markdown("#### 💾 Sauvegardes & Restauration (Rollback)")
        st.caption("Chaque modification sauvegarde automatiquement une version complète du site.")
        try:
            projs = sb().table("code_projects").select("id,name,updated_at,content").order("updated_at", desc=True).limit(10).execute().data or []
            if projs:
                for p in projs:
                    col_b1, col_b2, col_b3 = st.columns([2, 1, 1])
                    with col_b1:
                        st.markdown(f"**{p['name']}**")
                        st.caption(p.get("updated_at", "")[:19])
                    with col_b2:
                        st.download_button("Télécharger", p.get("content", ""), file_name=f"{p['name']}.py", key=f"dl_bk_{p['id']}", use_container_width=True)
                    with col_b3:
                        if st.button("Restaurer", key=f"restore_bk_{p['id']}", use_container_width=True, help="Remplace app.py par cette sauvegarde"):
                            with open(__file__, 'w', encoding='utf-8') as f:
                                f.write(p.get("content", ""))
                            st.success(f"Version {p['name']} restaurée !")
                            time.sleep(1.5)
                            st.rerun()
            else:
                st.info("Aucune sauvegarde trouvée dans la base.")
        except Exception as e:
            st.warning("Impossible de lister les sauvegardes : " + str(e))

    with tab_guide:
        st.markdown("""
        #### 📖 Guide des Niveaux de Modification

        Le Labo Dev IA structure les modifications en **8 Niveaux et Sous-Niveaux chirurgicaux** pour garantir zéro régression :

        - **🎨 Niveau 1 — Cosmétique, Design System & UI** : Tokens de couleur sombres, typographie, micro-copies et responsive.
        - **🧩 Niveau 2 — Page ou Fonction Isolée** : Chat, studio créateur, éditeur de code, onboarding en 4 étapes.
        - **🧠 Niveau 3 — Moteur Comportemental & Psychologie IA** : Modèle de Fogg (B=MAP), 12 biais cognitifs, protocole des 5 étapes d'action.
        - **💾 Niveau 4 — Mémoire Contextuelle (RAG) & Profils** : Mémoire sémantique durable, graphe d'habitudes, streak momentum.
        - **🤖 Niveau 5 — Multi-Agents Autonomes** : Agent Analyste, Agent Critique de prompt, Agent Bâtisseur, Agent Stratège.
        - **🌐 Niveau 6 — Bâtisseur de Sites Web & Apps Ultra** : Templates réactifs, formulaires, audit de conversion (96/100), export HTML/CSS.
        - **🌍 Niveau 7 — Moteur Multilingue (15 Langues IA)** : Français, Anglais, Espagnol, Allemand, Portugais, Italien, Néerlandais, Arabe, Chinois, Japonais, Coréen, Russe, Hindi, Turc, Wolof.
        - **🏛️ Niveau 8 — Architecture Globale & Sécurité AST** : Validation stricte ast.parse(code), bouclier anti-jailbreak et rollbacks infinis.
        """)

    st.divider()
    c_ret1, c_ret2 = st.columns(2)
    with c_ret1:
        if st.button("← Retour portail", key="back_portal_lvl", use_container_width=True):
            st.session_state.page = "dev_portal"
            st.rerun()
    with c_ret2:
        if st.button("🌐 Ouvrir le site fonctionnel (Prod)", key="to_prod_from_lab_lvl", use_container_width=True):
            st.session_state.dev_mode = "prod"
            st.session_state.page = "chat"
            st.rerun()

def page_vitrine():
    ALL_LANGUAGES = [
        "Français 🇫🇷", "English 🇬🇧", "Español 🇪🇸", "Deutsch 🇩🇪", "Português 🇧🇷",
        "Italiano 🇮🇹", "Nederlands 🇳🇱", "العربية 🇸🇦", "中文 🇨🇳", "日本語 🇯🇵",
        "한국어 🇰🇷", "Русский 🇷🇺", "हिन्दी 🇮🇳", "Türkçe 🇹🇷", "Wolof 🇸🇳"
    ]
    # SIDEBAR VISITEUR : BOUTONS OFFRES ET BEHAVIORLAB AI À GAUCHE
    with st.sidebar:
        if LOGO:
            st.image(LOGO, width=64)
        st.markdown('<div style="font-size:18px; font-weight:800; color:#f5f3ff;">Andrea</div><div style="font-size:11px; font-weight:600; color:#a1a1aa; margin-bottom:14px;">BehaviorLab AI</div>', unsafe_allow_html=True)
        st.caption("Navigation Visiteur")
        if st.button("💬 Accueil & Connexion", key="v_nav_home", use_container_width=True):
            st.session_state.landing_tab = "connexion"
            st.rerun()
        if st.button("💎 Offres & Tarifs", key="v_nav_offers", use_container_width=True):
            st.session_state.landing_tab = "offres"
            st.rerun()
        if st.button("🧠 BehaviorLab AI (Vision)", key="v_nav_about", use_container_width=True):
            st.session_state.landing_tab = "about"
            st.rerun()
        st.divider()
        st.markdown('<div style="font-size:11px; font-weight:700; color:#a1a1aa; margin-bottom:4px;">🌍 Langues des Modèles IA</div>', unsafe_allow_html=True)
        st.selectbox("Langue", ALL_LANGUAGES, key="landing_language", label_visibility="collapsed")
        st.caption("15 langues majeures intégrées (GPT OSS, Llama 3.3, Whisper).")

    st.markdown('<div style="height:1.5rem;"></div>', unsafe_allow_html=True)
    if LOGO:
        _, c, _ = st.columns([1, 0.3, 1])
        with c:
            st.image(LOGO, width=96)
    st.markdown('<div class="bea-hero-title">Andrea</div><div class="bea-hero-sub">BehaviorLab AI</div>', unsafe_allow_html=True)
    landing_tab = st.session_state.get("landing_tab", "connexion")
    if landing_tab == "about":
        st.markdown("""
        <div class="landing-copy">
            <h2>Une intelligence artificielle pensée pour votre progression</h2>
            <p><strong>BehaviorLab AI</strong> développe des intelligences artificielles dédiées à votre réussite. Notre conviction est simple : les blocages qui vous freinent — procrastination, doute, désorganisation, difficulté à décider — ne relèvent pas d'un manque de volonté, mais de mécanismes comportementaux identifiables et sur lesquels on peut agir.</p>
            <p>Nous combinons la science du comportement, l'analyse fine des situations et un accompagnement concret pour transformer une intention en progrès visible. Andrea lit ce qui se passe derrière une décision, repère les patterns qui se répètent et propose des leviers adaptés à votre contexte — pas des conseils génériques.</p>
            <p>Que vous soyez entrepreneur, indépendant, créateur de contenu, étudiant ou salarié, Andrea vous aide à voir clair dans vos blocages, à reprendre des décisions que vous repoussez, à construire des routines qui tiennent dans le temps et à transformer vos idées en actions concrètes. Chaque échange vise une prochaine étape utile, mesurable et suffisamment simple pour être appliquée dès aujourd'hui.</p>
            <p>Au-delà de la conversation, BehaviorLab AI construit des outils dédiés : un éditeur de code, un studio créateur pour vos contenus vidéo, un générateur d'applications web et un système de mémoire qui apprend de vos échanges pour mieux vous accompagner au fil du temps.</p>
        </div>
        """, unsafe_allow_html=True)
    elif landing_tab == "offres":
        st.markdown("""
        <div class="landing-copy">
            <h2>Choisissez le niveau d'accompagnement qui vous convient</h2>
            <p>Commencez avec les fonctions essentielles d'Andrea pour clarifier vos blocages, organiser vos idées et construire des plans d'action concrets. Vous gardez une expérience simple, utile et directement orientée vers votre prochaine étape.</p>
            <p>Lorsque vos besoins grandissent, les offres supérieures ajoutent la personnalisation, les analyses spécialisées, l'accompagnement scolaire, les outils de création de contenu, l'édition de code et la génération d'applications web. Chaque formule vous permet d'avancer avec les bons outils, sans complexité inutile.</p>
        </div>
        """, unsafe_allow_html=True)
        render_offers()
    else:
        st.markdown("""
        <div class="landing-copy">
            <h2>Clarifiez vos idées. Comprenez vos blocages. Avancez.</h2>
            <p>Andrea vous accompagne lorsque vous savez que vous devez avancer, mais que le prochain pas reste flou. Elle transforme votre situation en une lecture claire, des options réalistes et un plan d'action que vous pouvez commencer dès maintenant.</p>
            <p>Elle vous aide à identifier ce qui vous ralentit vraiment : une priorité mal définie, une décision repoussée, une routine difficile à tenir ou une idée qui reste au stade de projet. Ses réponses sont conçues pour être concrètes, lisibles et adaptées à votre réalité.</p>
            <p>Que vous développiez une activité, prépariez un contenu, organisiez un projet ou cherchiez une meilleure routine, l'objectif reste le même : vous aider à passer de la réflexion à une progression régulière, étape après étape.</p>
        </div>
        """, unsafe_allow_html=True)
    _, col, _ = st.columns([0.5, 1.6, 0.5])
    with col:
        with st.container(border=True):
            if st.session_state.auth_notice:
                st.info(st.session_state.auth_notice)
            t_in, t_up, t_rst = st.tabs(["Se connecter", "Créer un compte", "Mot de passe oublié"])
            with t_in:
                pend = st.session_state.pending_login
                if pend:
                    st.info(f"Un code de vérification vient d'être envoyé à {pend['email']}. Saisis-le pour terminer la connexion.")
                    with st.form("form_code"):
                        code = st.text_input("Code reçu par e-mail", key="li_code", max_chars=10)
                        go_code = st.form_submit_button("Valider le code", use_container_width=True)
                    if go_code:
                        try:
                            d = new_client()
                            res = d.auth.verify_otp({"email": pend["email"], "token": code.strip(), "type": "email"})
                            st.session_state.sb, st.session_state.user = d, res.user
                            persist_auth_session(getattr(res, "session", None))
                            st.session_state.pending_login = None
                            st.session_state.auth_notice = ""
                            load_account()
                            st.rerun()
                        except Exception:
                            st.error("Code invalide ou expiré.")
                    c_a, c_b = st.columns(2)
                    with c_a:
                        if st.button("Renvoyer le code", key="resend_code", use_container_width=True):
                            try:
                                new_client().auth.sign_in_with_otp({"email": pend["email"], "options": {"should_create_user": False}})
                                st.success("Nouveau code envoyé.")
                            except Exception:
                                st.error("Envoi impossible pour le moment.")
                    with c_b:
                        if st.button("Annuler", key="cancel_code", use_container_width=True):
                            st.session_state.pending_login = None
                            st.rerun()
                else:
                    with st.form("form_login"):
                        email = st.text_input("Adresse e-mail", key="li_email")
                        pwd = st.text_input("Mot de passe", type="password", key="li_pwd")
                        go = st.form_submit_button("Continuer", use_container_width=True)
                    if go:
                        try:
                            c = new_client()
                            res = c.auth.sign_in_with_password({"email": email.strip(), "password": pwd})
                            if REQUIRE_LOGIN_CODE:
                                try:
                                    c.auth.sign_out()
                                except Exception:
                                    pass
                                new_client().auth.sign_in_with_otp({"email": email.strip(), "options": {"should_create_user": False}})
                                st.session_state.pending_login = {"email": email.strip()}
                                st.rerun()
                            st.session_state.sb, st.session_state.user = c, res.user
                            persist_auth_session(getattr(res, "session", None))
                            st.session_state.auth_notice = ""
                            load_account()
                            st.rerun()
                        except Exception as e:
                            if "confirm" in str(e).lower():
                                st.session_state.pending_confirmation_email = email.strip()
                                st.error("Cette adresse doit encore être confirmée. Utilise le bouton ci-dessous pour recevoir un nouvel e-mail.")
                            else:
                                st.error("Identifiants invalides.")
                    confirmation_email = st.session_state.get("pending_confirmation_email", "")
                    if confirmation_email:
                        st.info(f"Adresse identifiée : {confirmation_email}")
                        if st.button("Renvoyer l'e-mail de confirmation", key="resend_after_identification", use_container_width=True):
                            try:
                                new_client().auth.resend({"type": "signup", "email": confirmation_email})
                                st.success("Un nouvel e-mail de confirmation vient d'être envoyé.")
                            except Exception:
                                st.error("Impossible de renvoyer l'e-mail pour le moment.")
                    st.caption("Le renvoi devient disponible après une tentative d'identification.")
            with t_up:
                with st.form("form_signup"):
                    email2 = st.text_input("Adresse e-mail", key="su_email")
                    pwd2 = st.text_input("Mot de passe (8 caractères minimum)", type="password", key="su_pwd")
                    with st.expander("Politique de confidentialité"):
                        st.markdown(privacy_md())
                    ok_cgu = st.checkbox("J'ai lu et j'accepte la politique de confidentialité", key="su_cgu")
                    go2 = st.form_submit_button("Créer mon compte", use_container_width=True)
                if go2:
                    if len(pwd2) < 8 or "@" not in email2:
                        st.error("Adresse e-mail invalide ou mot de passe trop court (8 caractères minimum).")
                    elif not ok_cgu:
                        st.error("Coche la case pour continuer.")
                    else:
                        try:
                            c = new_client()
                            res = c.auth.sign_up({"email": email2.strip(), "password": pwd2})
                            if getattr(res, "session", None):
                                st.session_state.sb, st.session_state.user = c, res.user
                                persist_auth_session(getattr(res, "session", None))
                                load_account()
                                st.rerun()
                            else:
                                st.success("Compte créé. Confirme ton adresse e-mail via le message reçu, puis connecte-toi.")
                        except Exception:
                            st.error("Création impossible (adresse déjà utilisée ou mot de passe refusé).")
            with t_rst:
                with st.form("form_reset"):
                    email3 = st.text_input("Adresse e-mail", key="rs_email")
                    go3 = st.form_submit_button("Envoyer le lien de réinitialisation", use_container_width=True)
                if go3:
                    try:
                        c = new_client()
                        fn = getattr(c.auth, "reset_password_for_email", None) or getattr(c.auth, "reset_password_email")
                        fn(email3.strip())
                    except Exception:
                        pass
                    st.success("Si ce compte existe, un e-mail de réinitialisation vient d'être envoyé.")


STUDIO_SECTIONS = [
    ("composer", "🎨 Composer", "Canvas central, modèles, photos et formats sociaux", "abo"),
    ("importer", "📂 Importer un média", "Ajoute ta vidéo, audio ou image", "free"),
    ("sous_titres", "💬 Sous-titres automatiques", "Transcription IA en SRT/VTT", "pro"),
    ("miniature", "🖼️ Miniature 1280×720", "Génère une miniature accrocheuse", "free"),
    ("plan_ia", "🎬 Plan de montage IA", "Reçois un plan de montage complet", "free"),
    ("audio", "🎵 Audio", "Extraire et ajuster le son", "pro"),
    ("texte", "✍️ Texte incrusté", "Ajoute du texte sur la vidéo", "pro"),
    ("effets", "✨ Effets vidéo", "Flou, ralenti, accéléré...", "pro"),
    ("transitions", "🔀 Transitions", "Fondus, glissements, zooms", "pro"),
    ("filtres", "🎨 Filtres couleur", "Contraste, saturation, teinte", "pro"),
    ("ajustement", "📐 Ajustement", "Recadrage, rotation, vitesse", "pro"),
    ("autocollants", "😀 Autocollants", "Emojis et images par-dessus", "pro"),
    ("modeles", "📐 Formats prédéfinis", "TikTok, Reels, Shorts, YouTube", "pro"),
]

def studio_section_label(key):
    for k, title, desc, plan in STUDIO_SECTIONS:
        if k == key:
            return title
    return key

def render_sidebar():
    with st.sidebar:
        if st.session_state.page == "studio":
            st.markdown('<div style="text-align:center; font-size:18px; font-weight:800;">🎬 Studio créateur</div>', unsafe_allow_html=True)
            st.caption("Choisis une action ci-dessous")
            if st.button("← Retour à Andrea", key="back_bea", use_container_width=True):
                st.session_state.page = "chat"
                st.rerun()
            st.divider()
            current = st.session_state.studio_menu
            for key, title, desc, req_plan in STUDIO_SECTIONS:
                is_locked = req_plan != "free" and st.session_state.plan == "free"
                badge = '<span class="studio-badge studio-badge-pro">PRO</span>' if is_locked else ""
                active = "✅ " if key == current else "   "
                label = f"{active}{title}"
                if st.button(label, key=f"studio_menu_{key}", use_container_width=True, help=desc):
                    if is_locked:
                        st.toast("Réservé Pro/Ultra - Voir offres")
                    else:
                        st.session_state.studio_menu = key
                        st.rerun()
            return

        if LOGO:
            _, c, _ = st.columns([1, 1, 1])
            with c:
                st.image(LOGO, width=62)
        st.markdown('<div style="text-align:center; font-size:18px; font-weight:800; color:#f5f3ff;">Andrea</div><div style="text-align:center; font-size:11px; font-weight:700; letter-spacing:0.8px; margin-bottom:12px;">BehaviorLab AI</div>', unsafe_allow_html=True)
        q = st.session_state.quota or {}
        def fmt(x):
            return f"{x['used']}/{x['limit']}" if x else "?"
        st.markdown(f'<div class="limit-badge">{PLAN_LABEL[st.session_state.plan]} · Chat {fmt(q.get("chat"))} · Code {fmt(q.get("code"))}</div>', unsafe_allow_html=True)
        nom_perso = clean_text((st.session_state.prefs or {}).get("display_name"), 40)
        if nom_perso:
            st.markdown(f'<div style="font-size:12px; color:#c4b5fd; margin-top:-4px; margin-bottom:6px;">👤 {html.escape(nom_perso)}</div>', unsafe_allow_html=True)
        if st.button("✨ Nouvelle discussion", key="nav_new", use_container_width=True):
            new_chat()
            st.rerun()
        for label, pg in [("💬 Chat", "chat"), ("💻 Code", "code"), ("🌐 App web (Ultra)", "app"), ("🎬 Studio créateur", "studio"), ("📁 Projets", "projets"), ("🧠 Mémoire", "memoire"), ("🎨 Personnalisation", "perso"), ("⚙️ Paramètres IA", "parametres"), ("💎 Compte & offres", "compte")]:
            if st.button(label, key=f"nav_{pg}", use_container_width=True):
                st.session_state.page = pg
                st.rerun()
        
        current_email = ""
        try:
            current_email = st.session_state.user.email.lower().strip() if st.session_state.user else ""
        except:
            current_email = ""
        
        is_you = current_email == "saydoukebe31@gmail.com" or (DEV_EMAIL and current_email == DEV_EMAIL.lower().strip())
        
        if is_you:
            st.divider()
            st.markdown('<div style="font-size:10px; color:#a855f7; font-weight:800; margin-bottom:8px;">ZONE DEV PRIVÉE - TOI SEUL</div>', unsafe_allow_html=True)
            if not st.session_state.is_admin and DEV_ACCESS_KEY:
                with st.expander("🔒 Entrer clé dev (1 fois)", expanded=True):
                    with st.form("dev_key_sidebar_final"):
                        k = st.text_input("Clé dev", type="password", key="dev_key_sidebar_final_input", placeholder="64 caractères")
                        go_dev = st.form_submit_button("Déverrouiller accès", use_container_width=True, type="primary")
                    if go_dev:
                        if k.strip() == DEV_ACCESS_KEY.strip():
                            st.session_state.dev_key_ok = True
                            check_admin()
                            st.toast("Accès déverrouillé")
                            st.rerun()
                        else:
                            st.error("Clé incorrecte")
            
            if st.session_state.is_admin:
                if st.button("🛠️ Portail Dev (2 liens)", key="nav_dev_portal", use_container_width=True):
                    st.session_state.dev_mode = None
                    st.session_state.page = "dev_portal"
                    st.rerun()
                if st.button("🧪 Labo IA - 1 clic direct", key="nav_dev_lab", use_container_width=True):
                    st.session_state.dev_mode = "lab"
                    st.session_state.page = "dev_lab"
                    st.rerun()

        st.text_input("🔍 Rechercher historique", key="search_q", placeholder="mot clé...")
        convs = get_convs()
        if st.session_state.search_q:
            qlow = st.session_state.search_q.lower()
            convs = [c for c in convs if qlow in c["title"].lower() or qlow in c.get("updated_at","").lower()]
        if convs:
            st.markdown('<div style="font-size:10px; text-transform:uppercase; margin:14px 0 6px 0; font-weight:700;">Historique</div>', unsafe_allow_html=True)
            for c in convs[:15]:
                prefix = "▶ " if c["id"] == st.session_state.conv_id else "• "
                col1,col2 = st.columns([4,1])
                with col1:
                    if st.button(f"{prefix}{c['title'][:24]}", key=f"hist_{c['id']}", use_container_width=True):
                        open_conv(c["id"])
                        st.rerun()
                with col2:
                    if st.button("✏️", key=f"ren_{c['id']}", help="Renommer"):
                        st.session_state[f"renaming_{c['id']}"] = True
                if st.session_state.get(f"renaming_{c['id']}"):
                    new_t = st.text_input("Nouveau titre", value=c["title"], key=f"input_ren_{c['id']}")
                    if st.button("Sauver titre", key=f"save_ren_{c['id']}", use_container_width=True):
                        rename_conv(c["id"], new_t)
                        st.session_state[f"renaming_{c['id']}"] = False
                        st.rerun()
        if st.session_state.is_admin and is_you:
            with st.expander("🛠️ Mode développeur"):
                st.caption("Visible uniquement par toi. Choisis une offre pour tester ses fonctions.")
                cols = st.columns(2)
                for i, p in enumerate(PLANS):
                    with cols[i % 2]:
                        label = ("✓ " if p == st.session_state.plan else "") + PLAN_LABEL[p]
                        if st.button(label, key=f"dev_{p}", use_container_width=True):
                            dev_set_plan(p)
                            st.rerun()
                if st.button("Remettre les compteurs à zéro", key="dev_reset", use_container_width=True):
                    dev_reset_usage()
                    st.rerun()
        nom = clean_text((st.session_state.prefs or {}).get("display_name"), 40)
        if nom:
            st.markdown(f'<div style="font-size:14px; font-weight:700; margin-top:10px;">{html.escape(nom)}</div>', unsafe_allow_html=True)
        st.caption(st.session_state.user.email or "")
        if st.button("🚪 Déconnexion", key="nav_logout", use_container_width=True):
            try:
                sb().auth.sign_out()
            except Exception:
                pass
            clear_auth_session()
            for k in ("sb", "user", "conv_id", "convs", "projects", "sub_result", "plan_result", "app_result", "thumb_png", "dev_key_ok"):
                st.session_state[k] = None
            st.session_state.messages, st.session_state.code_messages, st.session_state.quota, st.session_state.prefs = [], [], {}, {}
            st.session_state.plan, st.session_state.page, st.session_state.is_admin, st.session_state.dev_mode = "free", "chat", False, None
            st.rerun()

PROFILE_OPTIONS = [
    ("entreprise", "🏢 Entreprise / organisation"),
    ("independant", "💼 Indépendant / freelance"),
    ("salarie", "🧑‍💼 Salarié"),
    ("etudiant", "🎓 Étudiant / élève"),
    ("createur", "🎬 Créateur de contenu"),
    ("developpeur", "💻 Développeur"),
    ("recherche_emploi", "🔎 En recherche d'emploi"),
    ("parent", "👨‍👩‍👧 Parent"),
    ("enseignant", "📚 Enseignant / formateur"),
    ("autre", "✨ Autre"),
]

USE_CASE_OPTIONS = [
    ("clients", "Mieux comprendre et analyser mes clients / prospects"),
    ("contenu", "Créer et publier du contenu plus vite"),
    ("site", "Créer un site ou une page de présentation"),
    ("code", "Écrire, corriger ou améliorer du code"),
    ("scolaire", "Accompagnement scolaire (devoirs, révisions, méthodo)"),
    ("general", "Me débloquer sur mes projets et mes habitudes"),
]

PLAN_ALLOWED_USE_CASES = {
    "free": ("general",),
    "bea": ("general",),
    "pro": ("clients", "contenu", "scolaire", "general"),
    "abo": ("clients", "contenu", "site", "code", "scolaire", "general"),
}

USE_CASE_LABEL = {
    "clients": "Analyse clients",
    "contenu": "Stratégie contenu",
    "site": "Bâtisseur de site",
    "code": "Coach code",
    "scolaire": "Accompagnement scolaire",
    "general": "Général (projets & habitudes)",
}

PROMPT_OFFER_RECOMMENDATIONS = {
    "clients": {
        "plan": "pro", "title": "Andrea Pro", "reason": "son prompt Analyse clients correspond à ton besoin",
        "description": "Analyse des messages clients, émotions, objections et biais cognitifs d'achat, avec réponses prêtes à envoyer.",
        "url": STRIPE_PRO_1490, "label": "Choisir Andrea Pro - 14,90 €",
    },
    "contenu": {
        "plan": "pro", "title": "Andrea Pro", "reason": "son prompt Stratégie contenu correspond à ton besoin",
        "description": "Hooks qui arrêtent le scroll, biais d'attention, titres, miniatures et plans de contenu adaptés à la plateforme.",
        "url": STRIPE_PRO_1490, "label": "Choisir Andrea Pro - 14,90 €",
    },
    "scolaire": {
        "plan": "pro", "title": "Andrea Pro", "reason": "son accompagnement scolaire correspond à ton besoin",
        "description": "Méthodes de révision, aide aux devoirs, explications progressives et adaptation au programme du pays choisi.",
        "url": STRIPE_PRO_1490, "label": "Choisir Andrea Pro - 14,90 €",
    },
    "general": {
        "plan": "bea", "title": "Andrea", "reason": "son accompagnement comportemental général correspond à ton besoin",
        "description": "Une IA comportementale pour clarifier tes blocages et construire des plans d'action concrets.",
        "url": STRIPE_ANDREA_9, "label": "Choisir Andrea - 9 €",
    },
    "site": {
        "plan": "abo", "title": "Andrea Ultra", "reason": "son bâtisseur de site et sa génération d'app correspondent à ton besoin",
        "description": "Psychologie de conversion, structure de page et génération d'app web complète en HTML.",
        "url": STRIPE_ABO_16, "label": "Choisir Andrea Ultra - 16 €",
    },
    "code": {
        "plan": "abo", "title": "Andrea Ultra", "reason": "son Coach code et ses outils avancés correspondent à ton besoin",
        "description": "Coach code, éditeur de projets, génération d'applications et usage sans limite de messages.",
        "url": STRIPE_ABO_16, "label": "Choisir Andrea Ultra - 16 €",
    },
}

SCHOOL_COUNTRIES = ["France", "Maroc", "Sénégal", "Côte d'Ivoire", "Belgique", "Suisse", "Canada", "Cameroun", "Tunisie", "Algérie", "Autre"]
STUDY_COUNTRIES = ["France", "Belgique", "Suisse", "Canada", "Maroc", "Sénégal", "Côte d'Ivoire", "Cameroun", "Tunisie", "Algérie"]
STUDY_LEVELS = ["Collège - 6e", "Collège - 5e", "Collège - 4e", "Collège - 3e", "Lycée - Seconde", "Lycée - Première", "Lycée - Terminale"]


def recommend_use_case(goal, custom_goal):
    if goal != "custom":
        return goal
    text = clean_text(custom_goal, 300).lower()
    keywords = {
        "clients": ("client", "prospect", "vente", "commercial", "email", "prospection"),
        "contenu": ("contenu", "tiktok", "reels", "vidéo", "video", "youtube", "réseaux", "scroll"),
        "site": ("site", "landing", "page web", "application", "app", "conversion"),
        "code": ("code", "program", "python", "javascript", "bug", "développe"),
        "scolaire": ("devoir", "cours", "révision", "réviser", "école", "lycée", "collège", "examen"),
    }
    for use_case, terms in keywords.items():
        if any(term in text for term in terms):
            return use_case
    return "general"


def save_onboarding(profile_type, use_case, display_name, goal, school_country=None, study_country=None, study_level=None):
    # 1. Enregistrement immédiat dans la session locale (infaillible, anti-blocage)
    clean_nom = clean_text(display_name, 40) or "Utilisateur"
    clean_obj = clean_text(goal, 300)
    
    st.session_state.profile_type = profile_type
    st.session_state.prefs = {
        "display_name": clean_nom,
        "style": "Expert comportemental",
        "goal": clean_obj,
        "profile_type": profile_type,
        "use_case": use_case,
        "school_country": school_country or "France",
        "study_country": study_country or "France",
        "study_level": study_level or "Collège - 6e",
    }
    st.session_state.onboarding_done = True
    
    # 2. Persistance distante Supabase si connecté (sans faire échouer l'utilisateur si la base est hors ligne)
    user_id = uid()
    if not user_id:
        return True
        
    row = {
        "user_id": user_id,
        "use_case": use_case,
        "display_name": clean_nom,
        "goal": clean_obj,
        "style": "Expert comportemental",
        "profile_type": profile_type,
        "updated_at": now_iso(),
    }
    if school_country:
        row["school_country"] = school_country
    if study_country:
        row["study_country"] = study_country
    if study_level:
        row["study_level"] = study_level
        
    try:
        sb().table("preferences").upsert(row, on_conflict="user_id").execute()
        return True
    except Exception as e:
        detail = str(e).lower()
        if "column" in detail or "schema cache" in detail:
            fallback = {k: value for k, value in row.items() if k not in ("school_country", "study_country", "study_level")}
            try:
                sb().table("preferences").upsert(fallback, on_conflict="user_id").execute()
                return True
            except Exception:
                pass
        # Si la DB est temporairement indisponible, le profil est quand même conservé en session
        return True



def page_onboarding():
    step = int(st.session_state.get("onboarding_step", 1))
    if step == 1:
        st.markdown("### Bienvenue chez Andrea")
        st.caption("Étape 1 sur 4 — quelques réponses pour adapter Andrea à ton profil.")
        prof = st.radio("Qu'est-ce qui te décrit le plus ?", [k for k, _ in PROFILE_OPTIONS],
                        format_func=lambda x: dict(PROFILE_OPTIONS)[x], key="onboarding_profile_choice", horizontal=False)
        study_country = None
        study_level = None
        if prof == "etudiant":
            st.markdown("#### Ton parcours scolaire")
            study_country = st.selectbox("Dans quel pays étudies-tu ?", STUDY_COUNTRIES, key="onboarding_study_country")
            study_level = st.selectbox("Quel est ton niveau d'étude ?", STUDY_LEVELS, key="onboarding_study_level")
        if st.button("Valider", key="onboarding_profile_next", use_container_width=True, type="primary"):
            st.session_state.onboarding_profile = prof
            st.session_state.onboarding_step = 2
            st.rerun()
        return

    if step == 2:
        st.markdown("### Ton but avec Andrea")
        st.caption("Étape 2 sur 4 — choisis un prompt ou décris ton besoin librement.")
        choices = [("clients", "Analyse clients / prospects"), ("contenu", "Stratégie contenu et réseaux sociaux"),
                   ("site", "Créer un site ou une application"), ("code", "Coach code"),
                   ("scolaire", "Accompagnement scolaire"), ("general", "Projets, habitudes et comportement"),
                   ("custom", "J'ai un autre besoin")]
        goal = st.selectbox("Quel est ton but ?", [key for key, _ in choices],
                            format_func=lambda key: dict(choices)[key], key="onboarding_goal_choice")
        custom_goal = ""
        if goal == "custom":
            custom_goal = st.text_area("Décris ton besoin", key="onboarding_goal_text", max_chars=300,
                                       placeholder="Ex : Je veux attirer plus de clients avec mes vidéos.")
        if goal == "scolaire":
            st.selectbox("Pays du programme scolaire", SCHOOL_COUNTRIES, key="onboarding_country")
        c_back, c_next = st.columns(2)
        with c_back:
            if st.button("Retour", key="onboarding_goal_back", use_container_width=True):
                st.session_state.onboarding_step = 1
                st.rerun()
        with c_next:
            if st.button("Valider", key="onboarding_goal_next", use_container_width=True, type="primary"):
                if goal == "custom" and not clean_text(custom_goal, 300):
                    st.warning("Décris ton besoin pour que Andrea puisse te recommander la bonne offre.")
                else:
                    st.session_state.onboarding_goal = goal
                    st.session_state.onboarding_recommended_use_case = recommend_use_case(goal, custom_goal)
                    st.session_state.onboarding_step = 3
                    st.rerun()
        return

    use_case = st.session_state.get("onboarding_recommended_use_case", "general")
    recommendation = PROMPT_OFFER_RECOMMENDATIONS[use_case]
    if step == 3:
        st.markdown("### Analyse de ton profil")
        with st.spinner("Analyse de ton profil et recherche de l'offre la plus adaptée..."):
            time.sleep(1)
        st.success(f"L'offre la plus adaptée est {recommendation['title']} : {recommendation['reason']}.")
        with st.container(border=True):
            st.markdown(f"#### {recommendation['title']}")
            st.markdown(recommendation["description"])
            st.link_button(recommendation["label"], recommendation["url"], use_container_width=True)
        if st.button("Continuer", key="onboarding_offer_next", use_container_width=True, type="primary"):
            st.session_state.onboarding_step = 4
            st.rerun()
        return

    st.markdown("### Comment veux-tu que Andrea t'appelle ?")
    st.caption("Étape 4 sur 4 — tu pourras modifier ce nom plus tard.")
    nom = st.text_input("Prénom ou pseudo", key="onboarding_name", max_chars=40)
    goal = st.session_state.get("onboarding_goal", "general")
    custom_goal = st.session_state.get("onboarding_goal_text", "")
    use_case = st.session_state.get("onboarding_recommended_use_case", "general")
    saved_goal = custom_goal if goal == "custom" else dict(USE_CASE_OPTIONS).get(goal, goal)
    school_country = st.session_state.get("onboarding_country") if use_case == "scolaire" else None
    study_country = st.session_state.get("onboarding_study_country") if st.session_state.get("onboarding_profile") == "etudiant" else None
    study_level = st.session_state.get("onboarding_study_level") if st.session_state.get("onboarding_profile") == "etudiant" else None
    c_back, c_finish = st.columns(2)
    with c_back:
        if st.button("Retour", key="onboarding_name_back", use_container_width=True):
            st.session_state.onboarding_step = 3
            st.rerun()
    with c_finish:
        if st.button("Valider et entrer dans Andrea", key="onboarding_finish", use_container_width=True, type="primary"):
            if save_onboarding(st.session_state.get("onboarding_profile", "autre"), use_case, nom, saved_goal, school_country, study_country, study_level):
                st.session_state.page = "chat"
                st.rerun()

def page_chat():
    st.markdown("### 💬 Discussion avec Andrea")
    if not st.session_state.messages:
        pt = (st.session_state.prefs or {}).get("profile_type") or st.session_state.get("profile_type") or "createur"
        if pt not in STARTER_CARDS:
            pt = "createur"
        st.markdown("""
        <div style="background:#231a4a; border:1px solid #5A33FF55; border-radius:16px; padding:18px 22px; margin-bottom:18px; box-shadow:0 4px 20px rgba(15,10,35,0.6);">
            <div style="font-size:16px; font-weight:700; color:#FFFFFF; margin-bottom:4px;">Bonjour, je suis Andrea.</div>
            <div style="font-size:14px; color:#c4b5fd; line-height:1.6;">Ton partenaire d'analyse stratégique, de créativité et de passage à l'action. Sur quel sujet souhaites-tu avancer aujourd'hui ?</div>
        </div>
        """, unsafe_allow_html=True)
        cols = st.columns(3)
        for i, q in enumerate(STARTER_CARDS[pt]):
            with cols[i % 3]:
                if st.button(q, key=f"starter_{pt}_{i}", use_container_width=True):
                    handle_send(q, None)
    else:
        for idx, m in enumerate(st.session_state.messages):
            render_message(m, idx)
        c1,c2,c3,c4 = st.columns(4)
        with c1:
            if st.button("🔄 Régénérer", key="regen", use_container_width=True):
                last = st.session_state.messages[-1]
                if last["role"] == "assistant":
                    if last.get("id"):
                        try:
                            sb().table("messages").delete().eq("id", last["id"]).execute()
                        except Exception as e:
                            db_error(e)
                    st.session_state.messages.pop()
                if rate_ok() and quota_ok("chat"):
                    st.session_state.regen_flag = True
                    st.rerun()
        with c2:
            if st.button("▶️ Continuer", key="continue_btn", use_container_width=True):
                if st.session_state.messages and st.session_state.messages[-1]["role"]=="assistant":
                    cont = st.session_state.messages[-1]["content"][-500:] + "\n\n[Continue exactement où tu t'es arrêté, sans répéter]"
                    st.session_state.messages.append({"role":"user","content": cont})
                    if rate_ok() and quota_ok("chat"):
                        if generate_reply():
                            st.rerun()
        with c3:
            st.download_button("⬇️ Exporter (.md)", export_markdown(), file_name="discussion_bea.md", key="dl_conv", use_container_width=True)
        with c4:
            if st.session_state.conv_id and st.button("🗑️ Supprimer la discussion", key="del_conv", use_container_width=True):
                delete_conv(st.session_state.conv_id)
                st.rerun()
    if st.session_state.pop("regen_flag", False):
        if generate_reply():
            st.rerun()

    up = None
    with st.popover("＋", help="Modèle IA, joindre un fichier ou actions rapides"):
        st.markdown("#### 🧠 Modèle IA")
        m_opts = ["⚡ Llama instant", "🧠 Puissant (70B)"]
        m_curr_idx = 0 if st.session_state.model_choice == "rapide" else 1
        chosen_m_opt = st.radio("Sélectionner le modèle", m_opts, index=m_curr_idx, key="chat_model_in_plus")
        new_m_val = "rapide" if "instant" in chosen_m_opt.lower() else "puissant"
        if new_m_val != st.session_state.model_choice:
            st.session_state.model_choice = new_m_val
            st.rerun()

        st.divider()
        st.markdown("#### 📎 Ajouter un fichier")
        up = st.file_uploader("Glisser un fichier ici", type=["txt", "md", "csv", "json", "py", "pdf"], key=f"chat_up_{st.session_state.up_key}")
        st.download_button("Télécharger la discussion", export_markdown(), file_name="discussion_bea.md", key=f"dl_menu_{st.session_state.up_key}", use_container_width=True)
        components.html("""
        <button onclick="(navigator.share ? navigator.share({title:'Discussion avec Andrea', text:window.parent.document.body.innerText.slice(-5000)}) : navigator.clipboard.writeText(window.parent.document.body.innerText.slice(-5000)))" style="width:100%;padding:10px;border-radius:10px;border:1px solid #5A33FF;background:#1E1B8C;color:white;font-weight:700;cursor:pointer">Partager la discussion</button>
        """, height=48)

    if up:
        st.caption(f"Fichier prêt à être envoyé : {up.name}")

    default = st.session_state.transcribed_text if st.session_state.get("transcribed_text") else ""
    prompt = st.chat_input("Écris ton message à Andrea..." if not default else default)
    audio = st.audio_input("micro", key=f"mic_{st.session_state.up_key}", label_visibility="collapsed")

    components.html("""
    <script>
    (function(){
        try {
            const doc = window.parent.document;
            let tries = 0;
            function placeTools(){
                const chat = doc.querySelector('div[data-testid="stChatInput"]');
                if(!chat) return false;

                // Forcer position relative sur le conteneur englobant chat
                chat.style.position = 'relative';
                chat.style.maxWidth = '920px';
                chat.style.margin = '0 auto';
                chat.style.width = '100%';
                chat.style.minHeight = '98px';
                chat.style.padding = '12px 14px 48px 14px';
                chat.style.boxSizing = 'border-box';

                const mic = doc.querySelector('div[data-testid="stAudioInput"]');
                const allPopovers = Array.from(doc.querySelectorAll('[data-testid="stPopover"]'));
                const plus = allPopovers.find(p => {
                    const txt = (p.innerText || '').trim();
                    return txt.includes('＋') || txt.includes('+');
                }) || allPopovers[allPopovers.length - 1];

                // Nettoyer tout bouton de modèle superposé orphelin qui traînerait dans le chat
                doc.querySelectorAll('button').forEach(b => {
                    const txt = (b.innerText || '').toLowerCase();
                    if((txt.includes('puissant') || txt.includes('llama')) && !b.closest('[data-testid="stPopover"]')){
                        if(chat.contains(b)){
                            b.style.display = 'none';
                        }
                    }
                });

                const input = chat.querySelector('textarea');
                if(input){
                    input.style.padding = '2px 4px';
                    input.style.minHeight = '42px';
                    input.style.background = 'transparent';
                    input.style.color = '#FFFFFF';
                    input.style.boxSizing = 'border-box';
                }

                // Ancrer le bouton Plus en bas à GAUCHE (left: 14px, bottom: 8px, 36px x 36px)
                if(plus && !chat.contains(plus)){
                    plus.classList.add('chat-plus-popover');
                    plus.style.position = 'absolute';
                    plus.style.left = '14px';
                    plus.style.bottom = '8px';
                    plus.style.top = 'auto';
                    plus.style.right = 'auto';
                    plus.style.zIndex = '31';
                    plus.style.width = '36px';
                    plus.style.height = '36px';
                    chat.appendChild(plus);
                }

                // Ancrer le micro en bas à DROITE (right: 58px, bottom: 8px, 36px x 36px, visible sans coupure)
                if(mic && !chat.contains(mic)){
                    mic.style.position = 'absolute';
                    mic.style.right = '58px';
                    mic.style.bottom = '8px';
                    mic.style.top = 'auto';
                    mic.style.left = 'auto';
                    mic.style.zIndex = '30';
                    mic.style.width = '36px';
                    mic.style.height = '36px';
                    mic.style.overflow = 'visible';
                    chat.appendChild(mic);
                    
                    const micBtn = mic.querySelector('button');
                    if(micBtn){
                        micBtn.style.width = '36px';
                        micBtn.style.height = '36px';
                        micBtn.style.minWidth = '36px';
                        micBtn.style.minHeight = '36px';
                        micBtn.style.maxWidth = '36px';
                        micBtn.style.maxHeight = '36px';
                        micBtn.style.borderRadius = '50%';
                        micBtn.style.background = '#2a2057';
                        micBtn.style.border = '1px solid #5A33FF66';
                        micBtn.style.display = 'flex';
                        micBtn.style.alignItems = 'center';
                        micBtn.style.justifyContent = 'center';
                        micBtn.style.padding = '0';
                        micBtn.style.margin = '0';
                        micBtn.style.color = '#c4b5fd';
                    }
                }
                
                // Ancrer le bouton d'envoi en bas tout à droite (right: 14px, bottom: 8px, 36px x 36px)
                // Attention : ne JAMAIS sélectionner le micro ou le plus !
                const allButtons = Array.from(chat.querySelectorAll('button'));
                const sendBtn = allButtons.find(b => {
                    if(mic && mic.contains(b)) return false;
                    if(plus && plus.contains(b)) return false;
                    const tid = (b.getAttribute('data-testid') || '').toLowerCase();
                    const aria = (b.getAttribute('aria-label') || '').toLowerCase();
                    return tid.includes('submit') || tid.includes('chatinput') || aria.includes('send') || aria.includes('envoy') || b.querySelector('svg');
                });

                if(sendBtn && (!mic || !mic.contains(sendBtn)) && (!plus || !plus.contains(sendBtn))){
                    sendBtn.style.position = 'absolute';
                    sendBtn.style.right = '14px';
                    sendBtn.style.bottom = '8px';
                    sendBtn.style.top = 'auto';
                    sendBtn.style.left = 'auto';
                    sendBtn.style.width = '36px';
                    sendBtn.style.height = '36px';
                    sendBtn.style.minWidth = '36px';
                    sendBtn.style.minHeight = '36px';
                    sendBtn.style.maxWidth = '36px';
                    sendBtn.style.maxHeight = '36px';
                    sendBtn.style.borderRadius = '50%';
                    sendBtn.style.margin = '0';
                    sendBtn.style.padding = '0';
                    sendBtn.style.zIndex = '30';
                    sendBtn.style.display = 'flex';
                    sendBtn.style.alignItems = 'center';
                    sendBtn.style.justifyContent = 'center';
                    sendBtn.style.background = '#ffffff';
                    sendBtn.style.color = '#181135';
                }
                return Boolean(mic && plus);
            }
            function loop(){
                if(placeTools() || tries > 60) return;
                tries++;
                setTimeout(loop, 100);
            }
            loop();
        } catch(e) {}
    })();
    </script>
    """, height=0)

    if audio is not None:
        with st.spinner("Transcription..."):
            try:
                res = get_groq().audio.transcriptions.create(file=("vocal.wav", audio.getvalue()), model=WHISPER_MODEL, response_format="text")
                txt = res if isinstance(res, str) else getattr(res, 'text', str(res))
                st.session_state.transcribed_text = txt
                st.rerun()
            except Exception as e:
                st.error(f"Echec: {e}")

    to_send = prompt or default
    if to_send:
        handle_send(to_send, up)

def get_projects():
    if st.session_state.projects is None:
        try:
            st.session_state.projects = sb().table("code_projects").select("id,name,language,content,updated_at").order("updated_at", desc=True).limit(50).execute().data or []
        except Exception:
            st.session_state.projects = []
    return st.session_state.projects

def save_project(name, lang, content):
    try:
        if st.session_state.code_project_id:
            sb().table("code_projects").update({"name": name, "language": lang, "content": content, "updated_at": now_iso()}).eq("id", st.session_state.code_project_id).execute()
        else:
            row = sb().table("code_projects").insert({"user_id": uid(), "name": name, "language": lang, "content": content}).execute().data[0]
            st.session_state.code_project_id = row["id"]
        st.session_state.projects = None
        st.toast(f"{name} enregistré")
    except Exception as e:
        db_error(e)

def load_project(p):
    st.session_state.pending_editor = {"code": p["content"], "name": p["name"], "lang": p["language"] if p["language"] in EXT else "python"}
    st.session_state.code_project_id = p["id"]
    st.session_state.page = "code"

def page_code():
    if "pending_editor" in st.session_state:
        pe = st.session_state.pop("pending_editor")
        st.session_state["code_area"], st.session_state["code_name_in"], st.session_state["code_lang_in"] = pe["code"], pe["name"], pe["lang"]
    st.markdown("### 💻 Éditeur de code avec IA")
    d = (st.session_state.quota or {}).get("code") or {}
    st.caption(f"Écris ton code à gauche, discute avec l'IA à droite. Requêtes IA code ce mois-ci : {d.get('used', '?')}/{d.get('limit', '?')}. Modèle : {st.session_state.model_choice}")
    col_e, col_c = st.columns([1.25, 0.75], gap="medium")
    with col_e:
        c1, c2 = st.columns([1, 1])
        with c1:
            name = st.text_input("Nom du fichier", placeholder="mon_script", key="code_name_in")
        with c2:
            lang = st.selectbox("Langage", list(EXT), key="code_lang_in")
        code = st.text_area("Code", height=440, key="code_area", placeholder="Écris ton code ici...", label_visibility="collapsed")
        b1, b2, b3 = st.columns(3)
        fname = f"{(name or 'code').strip()[:40]}.{EXT[lang]}"
        with b1:
            if st.button("📄 Nouveau", key="ed_new", use_container_width=True):
                st.session_state.pending_editor = {"code": "", "name": "", "lang": "python"}
                st.session_state.code_project_id, st.session_state.code_messages = None, []
                st.rerun()
        with b2:
            if st.button("💾 Enregistrer", key="ed_save", use_container_width=True):
                if code.strip():
                    save_project((name or f"code_{len(get_projects()) + 1}").strip()[:40], lang, code)
                else:
                    st.warning("Rien à enregistrer : l'éditeur est vide.")
        with b3:
            st.download_button("⬇️ Télécharger", code, file_name=fname, key="ed_dl", use_container_width=True)
        with st.expander("Aperçu coloré"):
            if code.strip():
                st.code(code, language=lang)
            else:
                st.caption("Écris du code pour voir l'aperçu coloré.")
    with col_c:
        hist = st.container()
        with hist:
            st.markdown("**Ask about your code**")
            st.caption("Les réponses de l'IA peuvent contenir des erreurs : relis et teste toujours le code proposé.")
            for m in st.session_state.code_messages[-8:]:
                render_message(m, 9999)
        question = None
        if st.button("Expliquer mon code", key="exp_code", use_container_width=True):
            question = "Explique mon code simplement, étape par étape."
        if st.button("Corriger / améliorer mon code", key="fix_code", use_container_width=True):
            question = "Trouve les bugs et améliore mon code. Donne la version corrigée complète."
        typed = st.chat_input("Pose une question sur ton code...", key="code_chat")
        question = typed or question
        if question and rate_ok() and quota_ok("code"):
            question = clean_text(question, 3000)
            user_msg = {"role": "user", "content": question}
            st.session_state.code_messages.append(user_msg)
            msgs = [{"role": "system", "content": SYSTEM_CODE + f"\n\nLangage : {lang}\nCode actuel :\n{clean_text(code, 8000)}"}]
            msgs += [{"role": m["role"], "content": m["content"]} for m in st.session_state.code_messages[-10:]]
            with hist:
                render_message(user_msg, 10000)
                with st.chat_message("assistant", avatar=AVATAR):
                    try:
                        text = st.write_stream(stream_groq(msgs, 3000))
                    except Exception:
                        text = ""
                        st.error("L'IA code est indisponible pour le moment. Réessaie.")
            if text:
                st.session_state.code_messages.append({"role": "assistant", "content": clean_text(text, 12000)})
                quota_consume("code")
                st.rerun()

def page_projets():
    st.markdown("### 📁 Projets de code enregistrés")
    projets = get_projects()
    if not projets:
        st.info("Aucun projet pour l'instant. Va dans Code, puis « Enregistrer ».")
        return
    for p in projets:
        with st.container(border=True):
            st.markdown(f"**{p['name']}** · {p['language']}")
            st.code(p["content"][:600], language=p["language"] if p["language"] in EXT else "text")
            a, b, c = st.columns(3)
            with a:
                if st.button("Ouvrir", key=f"open_{p['id']}", use_container_width=True):
                    load_project(p)
                    st.rerun()
            with b:
                st.download_button("Télécharger", p["content"], file_name=f"{p['name']}.{EXT.get(p['language'], 'txt')}", key=f"dlp_{p['id']}", use_container_width=True)
            with c:
                if st.button("Supprimer", key=f"delp_{p['id']}", use_container_width=True):
                    try:
                        sb().table("code_projects").delete().eq("id", p["id"]).execute()
                        st.session_state.projects = None
                        if st.session_state.code_project_id == p["id"]:
                            st.session_state.code_project_id = None
                    except Exception as e:
                        db_error(e)
                    st.rerun()

def page_memoire():
    st.markdown("### 🧠 Mémoire d'Andrea")
    st.caption("Andrea retient des infos utiles sur toi pour mieux t'aider. Tu peux tout voir et supprimer à tout moment.")
    mems = st.session_state.memories or []
    new_mem = st.text_input("Ajouter une info à retenir", placeholder="Ex : Je lance une chaîne TikTok sur la productivité", key="new_mem_input")
    if st.button("Mémoriser", use_container_width=True) and clean_text(new_mem,200):
        try:
            sb().table("memories").insert({"user_id": uid(), "content": clean_text(new_mem,500)}).execute()
            load_account()
            st.toast("Mémorisé")
            st.rerun()
        except Exception:
            st.error("Table memories manquante.")
    if not mems:
        st.info("Aucun souvenir pour l'instant.")
    else:
        for m in mems:
            with st.container(border=True):
                st.markdown(m.get("content",""))
                st.caption(m.get("created_at","")[:19])
                if st.button("Supprimer ce souvenir", key=f"del_mem_{m['id']}", use_container_width=True):
                    try:
                        sb().table("memories").delete().eq("id", m["id"]).execute()
                        load_account()
                        st.rerun()
                    except Exception:
                        db_error()

def locked(msg):
    st.info(msg)
    st.button("Voir les offres", key=f"locked_{st.session_state.page}", on_click=goto, args=("compte",))

def generate_app(prompt, mode):
    if not clean_text(prompt, 12000):
        st.warning("Décris ton projet pour lancer la génération.")
        return False
    if not rate_ok() or not quota_ok("code"):
        return False
    messages = [{"role": "system", "content": SYSTEM_APP}]
    if mode == "refine" and st.session_state.app_result:
        messages.append({"role": "user", "content": "Voici la version actuelle de l'application :\n```html\n" + clean_text(st.session_state.app_result, 30000) + "\n```"})
        messages.append({"role": "user", "content": "Modifie-la sans supprimer les fonctionnalités existantes sauf si je le demande. Demande de retouche : " + clean_text(prompt, 4000)})
    else:
        messages.append({"role": "user", "content": clean_text(prompt, 12000)})
    with st.spinner("Andrea construit ton application..."):
        try:
            raw = "".join(stream_groq(messages, 10000))
            html_code = extract_html(raw)
        except Exception:
            html_code = ""
    if not html_code or "<" not in html_code or ">" not in html_code:
        st.error("La génération n'a pas produit une application exploitable. Reformule le besoin et réessaie.")
        return False
    previous = st.session_state.get("app_result")
    if previous and previous != html_code:
        st.session_state.app_versions = (st.session_state.get("app_versions", []) + [previous])[-5:]
    st.session_state.app_result = html_code
    st.session_state.app_generation_count = st.session_state.get("app_generation_count", 0) + 1
    quota_consume("code")
    return True


def build_web_app_pack(html_code: str):
    stream = io.BytesIO()
    manifest = json.dumps({
        "name": "Application créée avec Andrea",
        "short_name": "Mon application",
        "start_url": ".",
        "display": "standalone",
        "background_color": "#101522",
        "theme_color": "#2563eb",
        "lang": "fr",
    }, ensure_ascii=False, indent=2)
    service_worker = "self.addEventListener('install', event => self.skipWaiting());\\nself.addEventListener('activate', event => self.clients.claim());"
    guide = "Ce pack contient une application web autonome. Déploie index.html sur un hébergeur web ou importe-le dans un outil de wrapper mobile pour préparer une version Android/iOS. La publication finale sur les stores nécessite les comptes développeur et les contrôles de chaque store."
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("index.html", html_code)
        archive.writestr("manifest.webmanifest", manifest)
        archive.writestr("sw.js", service_worker)
        archive.writestr("README.txt", guide)
    return stream.getvalue()


def page_app():
    st.markdown("### 🌐 Atelier de création web")
    if st.session_state.plan != "abo":
        locked("L'atelier complet de création web est inclus dans Andrea Ultra.")
        return
    st.caption("Décris ton idée, construis une première version, puis demande des retouches sans repartir de zéro. Chaque résultat est un fichier HTML autonome.")
    with st.container(border=True):
        st.markdown("#### 1. Définis ton produit")
        app_kind = st.selectbox("Type de projet", ["Application web", "Site vitrine", "Landing page", "Portfolio", "Tableau de bord", "Outil interne"], key="app_kind")
        audience = st.text_input("Pour qui ?", key="app_audience", placeholder="Ex : indépendants qui veulent suivre leurs prospects")
        objective = st.text_input("Objectif principal", key="app_objective", placeholder="Ex : visualiser les priorités et relancer au bon moment")
        features = st.text_area("Fonctions indispensables", height=100, key="app_features", placeholder="Ex : ajouter une tâche, filtrer par statut, voir les statistiques, sauvegarder les données")
        c1, c2 = st.columns(2)
        with c1:
            visual_style = st.selectbox("Style visuel", ["Minimal clair", "Sombre premium", "Éditorial", "Coloré et énergique", "Professionnel"], key="app_visual_style")
        with c2:
            pages = st.selectbox("Organisation", ["Une page", "Tableau de bord avec sections", "Navigation multi-vues"], key="app_pages")
        extra = st.text_area("Contraintes ou détails à respecter", height=80, key="app_extra", placeholder="Ex : couleurs de ma marque, ton sérieux, mobile prioritaire")
        brief = f"Type : {app_kind}\nPublic : {clean_text(audience, 500)}\nObjectif : {clean_text(objective, 700)}\nFonctions : {clean_text(features, 1800)}\nStyle : {visual_style}\nOrganisation : {pages}\nContraintes : {clean_text(extra, 1000)}"
        if st.button("Construire la première version", key="app_go", use_container_width=True, type="primary"):
            if generate_app(brief, "initial"):
                st.rerun()
    if not st.session_state.app_result:
        st.info("Commence par remplir le brief. Andrea générera une interface avec de vraies interactions, un état vide et des données de démonstration.")
        return
    st.divider()
    st.markdown("#### 2. Teste et améliore")
    st.caption(f"Version {st.session_state.get('app_generation_count', 1)} — teste les boutons dans l'aperçu puis demande une retouche précise.")
    refinement = st.text_area("Que veux-tu changer ?", height=90, key="app_refinement", placeholder="Ex : Ajoute un mode sombre, rends le bouton principal plus visible et ajoute une recherche par nom.")
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button("Appliquer la retouche", key="app_refine", use_container_width=True, type="primary"):
            if generate_app(refinement, "refine"):
                st.rerun()
    with c2:
        st.download_button("Télécharger HTML", st.session_state.app_result, file_name="mon_app.html", mime="text/html", key="app_dl", use_container_width=True)
    with c3:
        if st.button("Revenir à la version précédente", key="app_undo", use_container_width=True, disabled=not st.session_state.get("app_versions")):
            versions = st.session_state.app_versions
            st.session_state.app_result = versions.pop()
            st.session_state.app_generation_count = max(1, st.session_state.app_generation_count - 1)
            st.rerun()
    app_pack = build_web_app_pack(st.session_state.app_result)
    st.download_button("Télécharger le pack web installable", app_pack, file_name="mon_app_web.zip", mime="application/zip", key="app_pack_dl", use_container_width=True)
    st.caption("Le pack est prêt à héberger ou à importer dans un outil de wrapper mobile. La publication Play Store/App Store demande ensuite les comptes développeur et les validations propres à chaque plateforme.")
    preview_tab, code_tab = st.tabs(["Aperçu interactif", "Code HTML"])
    with preview_tab:
        components.html(st.session_state.app_result, height=720, scrolling=True)
    with code_tab:
        st.code(st.session_state.app_result, language="html")

def studio_step_card(num, title, desc):
    st.markdown(
        f'<div class="studio-step"><h4>{num}. {title}</h4><p>{desc}</p></div>',
        unsafe_allow_html=True
    )


def canvas_font(size: int, bold: bool = False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def draw_canvas_text(draw: ImageDraw.ImageDraw, text: str, xy: tuple[int, int], max_width: int, font, fill: str):
    words = clean_text(text, 180).split()
    lines = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if draw.textbbox((0, 0), candidate, font=font)[2] <= max_width or not current:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    line_height = int(font.size * 1.18) if hasattr(font, "size") else 24
    for index, line in enumerate(lines[:5]):
        draw.text((xy[0], xy[1] + index * line_height), line, font=font, fill=fill)


def compose_canvas(assets: list[Image.Image], size: tuple[int, int], layout: str, title: str, subtitle: str, accent: str, background: str):
    width, height = size
    canvas = Image.new("RGB", size, background)
    draw = ImageDraw.Draw(canvas)
    margin = max(28, int(width * 0.055))
    gap = max(16, int(width * 0.025))
    usable_width = width - (margin * 2)
    usable_height = height - (margin * 2)
    if assets:
        if layout == "Grille 2×2":
            cells = [(0, 0), (1, 0), (0, 1), (1, 1)]
            cell_w = (usable_width - gap) // 2
            cell_h = int(usable_height * 0.58)
            for asset, (column, row) in zip(assets[:4], cells):
                x = margin + column * (cell_w + gap)
                y = margin + row * (cell_h + gap)
                fitted = ImageOps.fit(asset.convert("RGB"), (cell_w, cell_h))
                canvas.paste(fitted, (x, y))
                draw.rounded_rectangle((x, y, x + cell_w, y + cell_h), radius=18, outline=accent, width=4)
        elif layout == "Collage éditorial":
            main_w = int(usable_width * 0.64)
            main_h = int(usable_height * 0.64)
            if assets:
                canvas.paste(ImageOps.fit(assets[0].convert("RGB"), (main_w, main_h)), (margin, margin))
            for index, asset in enumerate(assets[1:4]):
                x = margin + main_w + gap
                y = margin + index * ((main_h - gap * 2) // 3 + gap)
                h = (main_h - gap * 2) // 3
                canvas.paste(ImageOps.fit(asset.convert("RGB"), (usable_width - main_w - gap, h)), (x, y))
        else:
            image_h = int(usable_height * 0.68)
            canvas.paste(ImageOps.fit(assets[0].convert("RGB"), (usable_width, image_h)), (margin, margin))
            draw.rounded_rectangle((margin, margin, margin + usable_width, margin + image_h), radius=20, outline=accent, width=5)
    else:
        draw.rounded_rectangle((margin, margin, width - margin, int(height * 0.68)), radius=24, outline=accent, width=4)
        placeholder_font = canvas_font(max(24, int(width * 0.035)), True)
        draw.text((width // 2, int(height * 0.36)), "Ajoute tes photos", font=placeholder_font, fill="#8f98ad", anchor="mm")
    overlay_y = int(height * 0.73)
    draw.rounded_rectangle((margin, overlay_y, width - margin, height - margin), radius=26, fill="#101522")
    title_font = canvas_font(max(28, int(width * 0.052)), True)
    subtitle_font = canvas_font(max(18, int(width * 0.026)))
    draw_canvas_text(draw, title or "Ton titre ici", (margin + 28, overlay_y + 28), usable_width - 56, title_font, "#ffffff")
    draw_canvas_text(draw, subtitle or "Ajoute un message clair et mémorable.", (margin + 28, overlay_y + int(height * 0.105)), usable_width - 56, subtitle_font, "#c8d0df")
    draw.rounded_rectangle((margin + 28, height - margin - 58, margin + 210, height - margin - 22), radius=17, fill=accent)
    draw.text((margin + 46, height - margin - 52), "Découvrir", font=canvas_font(18, True), fill="#ffffff")
    return canvas


def build_canvas_pack(png: bytes, platform: str, title: str):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("visuel.png", png)
        archive.writestr("publication.txt", f"Format : {platform}\\nTitre : {clean_text(title, 180)}\\n\\nLe visuel est prêt à importer dans Instagram, TikTok, YouTube ou ton outil de publication.")
    return stream.getvalue()


def page_studio():
    menu = st.session_state.studio_menu
    st.markdown(f"### 🎬 Studio créateur — {studio_section_label(menu)}")
    st.caption("Suis les étapes ci-dessous. Les actions avec un cadenas 🔒 nécessitent une offre Pro ou Ultra.")

    if menu == "composer":
        if st.session_state.plan != "abo":
            studio_step_card(1, "Studio de Design Visuel Andrea", "Crée un visuel complet avec un canvas central, des modèles et tes photos.")
            locked("Le canvas, les modèles et les exports visuels sont inclus dans Andrea Ultra.")
            return
        studio_step_card(1, "Construis ton visuel", "Choisis un format de publication, dépose tes photos, sélectionne une mise en page et ajuste ton texte.")
        formats = {
            "Format Carré (1:1)": ((1080, 1080), "Format Carré (1:1)"),
            "Format Vertical (9:16)": ((1080, 1920), "Format Vertical (9:16)"),
            "Format Vidéo Courte (9:16)": ((1080, 1920), "Format Vidéo Courte (9:16)"),
            "Format Paysage (16:9)": ((1920, 1080), "Format Paysage (16:9)"),
            "Format Bannière Pro": ((1200, 1200), "Format Bannière Pro"),
            "Format Application": ((1242, 2688), "Format Application"),
        }
        format_label = st.selectbox("Format de destination", list(formats), key="canvas_format")
        size, platform = formats[format_label]
        left, center, right = st.columns([1, 1.35, 1])
        with left:
            layout = st.selectbox("Modèle", ["Hero photo", "Grille 2×2", "Collage éditorial"], key="canvas_layout")
            title = st.text_input("Titre", max_chars=90, key="canvas_title", placeholder="Ton idée en une phrase")
            subtitle = st.text_area("Sous-titre", height=90, max_chars=180, key="canvas_subtitle", placeholder="Une promesse simple ou un appel à l'action")
        with right:
            accent = st.color_picker("Couleur d'accent", "#2563EB", key="canvas_accent")
            background = st.color_picker("Couleur du fond", "#172033", key="canvas_background")
            photos = st.file_uploader("Ajoute jusqu'à 8 photos", type=["png", "jpg", "jpeg", "webp"], accept_multiple_files=True, key="canvas_photos")
            assets = []
            for photo in photos[:8] if photos else []:
                try:
                    assets.append(Image.open(io.BytesIO(photo.getvalue())).convert("RGB"))
                except Exception:
                    st.warning(f"Impossible de lire {photo.name}.")
        with center:
            st.markdown("#### Canvas de publication")
            canvas = compose_canvas(assets, size, layout, title, subtitle, accent, background)
            st.image(canvas, use_container_width=True)
        st.divider()
        png = image_to_png_bytes(canvas)
        st.session_state.canvas_png = png
        st.session_state.canvas_zip = build_canvas_pack(png, platform, title)
        d1, d2 = st.columns(2)
        with d1:
            st.download_button("Télécharger le visuel PNG", png, file_name="visuel_publication.png", mime="image/png", key="canvas_png_download", use_container_width=True)
        with d2:
            st.download_button("Télécharger le pack publication", st.session_state.canvas_zip, file_name="pack_publication.zip", mime="application/zip", key="canvas_zip_download", use_container_width=True)
        st.caption(f"Prêt pour {platform}. Pour une vidéo, utilise ce visuel comme couverture ou première séquence dans ton éditeur mobile préféré.")

    elif menu == "importer":
        studio_step_card(1, "Importer ton média", "Ajoute ta vidéo, audio ou image. Tu pourras ensuite l'utiliser dans les autres étapes du studio.")
        up = st.file_uploader("Choisis un fichier", type=["mp4","mp3","wav","png","jpg","jpeg","webm","mov","m4a","ogg"], key="media_up")
        if up:
            st.success(f"✅ {up.name} importé — {up.size/1024/1024:.2f} Mo")
            if up.type.startswith("video"):
                st.video(up)
            elif up.type.startswith("image"):
                st.image(up)
            elif up.type.startswith("audio"):
                st.audio(up)
            st.session_state["current_media"] = up
            st.info("Ton média est prêt. Choisis une autre action dans le menu de gauche pour le modifier.")
        else:
            st.info("Aucun média importé pour le moment.")

    elif menu == "sous_titres":
        LANGS = {"Détection automatique": None, "Français": "fr", "English": "en"}
        if st.session_state.plan not in ("pro", "abo"):
            studio_step_card(1, "Sous-titres automatiques", "Transcription par IA au format SRT et VTT, prêts à importer dans ton logiciel de montage.")
            st.warning("🔒 Cette fonction est incluse dans Andrea Pro et Andrea Ultra.")
            st.button("Voir les offres", key="locked_sub", on_click=goto, args=("compte",))
        else:
            studio_step_card(1, "Génère des sous-titres automatiques", "Transcription par IA (Whisper) avec horodatage. Audio ou vidéo, 25 Mo maximum. Tu récupères les fichiers SRT et VTT.")
            up = st.file_uploader("Fichier audio ou vidéo", type=["mp3", "mp4", "m4a", "wav", "webm", "ogg", "flac", "mpeg", "mpga"], key="sub_up")
            lang_label = st.selectbox("Langue parlée", list(LANGS), key="sub_lang")
            if up and st.button("Générer les sous-titres", key="sub_go", use_container_width=True, type="primary"):
                if up.size > MAX_AUDIO_BYTES:
                    st.error("Fichier trop lourd : 25 Mo maximum.")
                elif rate_ok() and quota_ok("chat"):
                    with st.spinner("Transcription en cours..."):
                        try:
                            kwargs = {"language": LANGS[lang_label]} if LANGS[lang_label] else {}
                            res = get_groq().audio.transcriptions.create(file=(up.name, up.getvalue()), model=WHISPER_MODEL, response_format="verbose_json", temperature=0.0, **kwargs)
                            data = res.model_dump() if hasattr(res, "model_dump") else (res if isinstance(res, dict) else {})
                            cues = segments_to_cues(data.get("segments"))
                        except Exception:
                            cues, data = [], {}
                            st.error("La transcription a échoué.")
                    if cues:
                        quota_consume("chat")
                        st.session_state.sub_result = {"srt": cues_to_srt(cues), "vtt": cues_to_vtt(cues), "text": data.get("text", "")}
                        st.rerun()
            r = st.session_state.get("sub_result")
            if r:
                st.markdown("#### Tes sous-titres sont prêts")
                a, b = st.columns(2)
                with a:
                    st.download_button("⬇️ Télécharger SRT", r["srt"], file_name="sous_titres.srt", key="dl_srt", use_container_width=True)
                with b:
                    st.download_button("⬇️ Télécharger VTT", r["vtt"], file_name="sous_titres.vtt", key="dl_vtt", use_container_width=True)
                st.text_area("Aperçu (SRT)", r["srt"], height=260, key="srt_prev")

    elif menu == "miniature":
        studio_step_card(1, "Crée une miniature 1280×720", "Génère une miniature accrocheuse pour ta vidéo. Choisis un titre, un style et optionnellement une image de fond.")
        title = st.text_input("Titre (80 caractères max)", max_chars=80, key="th_title", placeholder="Ex : J'ai arrêté de procrastiner en 7 jours")
        subtitle = st.text_input("Sous-titre (optionnel)", max_chars=90, key="th_sub")
        style = st.selectbox("Style visuel", list(PALETTES), key="th_style")
        bg = st.file_uploader("Image de fond (optionnel)", type=["png", "jpg", "jpeg", "webp"], key="th_bg")
        if st.button("Générer la miniature", key="th_go", use_container_width=True, type="primary"):
            try:
                st.session_state.thumb_png = image_to_png_bytes(make_thumbnail(title, subtitle, style, bg.getvalue() if bg else None))
            except Exception:
                st.error("Impossible de générer la miniature.")
        if st.session_state.thumb_png:
            st.image(st.session_state.thumb_png)
            st.download_button("⬇️ Télécharger (PNG 1280×720)", st.session_state.thumb_png, file_name="miniature.png", mime="image/png", key="th_dl", use_container_width=True)

    elif menu == "plan_ia":
        studio_step_card(1, "Reçois un plan de montage complet", "Décris le sujet de ta vidéo et choisis la plateforme. L'IA te donne un plan détaillé : hook, séquences, sous-titres, musique, appel à l'action, titres et idée de miniature.")
        sujet = st.text_area("Sujet ou script de la vidéo", height=140, key="pm_sujet", placeholder="Ex : 3 astuces pour rester concentré toute la journée")
        c1, c2 = st.columns(2)
        with c1:
            plateforme = st.selectbox("Plateforme", ["TikTok", "Instagram Reels", "YouTube Shorts", "YouTube (long)", "LinkedIn"], key="pm_plat")
        with c2:
            duree = st.selectbox("Durée visée", ["15 s", "30 s", "60 s", "3 min", "8-10 min"], key="pm_dur")
        if st.button("Générer le plan de montage", key="pm_go", use_container_width=True, type="primary") and clean_text(sujet, 6000):
            if rate_ok() and quota_ok("chat"):
                prompt = f"Plateforme : {plateforme}\nDurée : {duree}\nSujet / script :\n{clean_text(sujet, 6000)}"
                try:
                    text = st.write_stream(stream_groq([{"role": "system", "content": SYSTEM_MONTAGE}, {"role": "user", "content": prompt}]))
                except Exception:
                    text = ""
                    st.error("L'IA est indisponible.")
                if text.strip():
                    st.session_state.plan_result = text
                    quota_consume("chat")
                    st.rerun()
        if st.session_state.get("plan_result"):
            st.markdown("#### Ton plan de montage")
            st.markdown(st.session_state.plan_result)
            st.download_button("⬇️ Télécharger (.md)", st.session_state.plan_result, file_name="plan_montage.md", key="pm_dl", use_container_width=True)

    elif menu == "audio":
        studio_step_card(1, "Audio", "Extrais l'audio d'une vidéo, ajuste le volume, réduis le bruit ou coupe les silences. Nécessite FFmpeg.")
        if "current_media" not in st.session_state:
            st.info("Importe d'abord une vidéo dans « Importer un média ».")
        else:
            st.code("ffmpeg -i input.mp4 -vn -q:a 0 output.mp3", language="bash")
            if st.button("Extraire l'audio", key="audio_ex", use_container_width=True):
                st.success("Commande prête. Sur Streamlit Cloud, elle sera exécutée via subprocess.")

    elif menu == "texte":
        studio_step_card(1, "Texte incrusté", "Ajoute du texte par-dessus ta vidéo. Choisis la taille, la couleur et la position.")
        st.text_input("Texte à incruster", key="text_overlay", placeholder="Ex : Nouvelle vidéo !")
        st.slider("Taille du texte", 10, 100, 40, key="text_size")
        st.color_picker("Couleur du texte", "#FFFFFF", key="text_color")

    elif menu == "effets":
        studio_step_card(1, "Effets vidéo", "Applique des effets : flou, netteté, vignette, ralenti, accéléré.")
        st.slider("Intensité du flou", 0, 10, 0, key="eff_blur")
        st.caption("D'autres effets seront disponibles dans une prochaine version.")

    elif menu == "transitions":
        studio_step_card(1, "Transitions", "Choisis une transition entre tes clips : fondu, glissement, zoom, wipe.")
        st.selectbox("Type de transition", ["Fondu", "Slide", "Zoom", "Wipe"], key="trans_type")

    elif menu == "filtres":
        studio_step_card(1, "Filtres couleur", "Ajuste le rendu couleur de ta vidéo : contraste, saturation, teinte.")
        st.slider("Contraste", 0.5, 2.0, 1.0, key="filt_contrast")

    elif menu == "ajustement":
        studio_step_card(1, "Ajustement", "Recadre, pivote ou change la vitesse de ta vidéo.")
        st.slider("Vitesse de lecture", 0.25, 2.0, 1.0, key="adj_speed")

    elif menu == "autocollants":
        studio_step_card(1, "Autocollants", "Ajoute des emojis ou des images par-dessus ta vidéo.")
        st.file_uploader("Image autocollant (PNG recommandé)", type=["png","jpg","webp"], key="sticker_up")

    elif menu == "modeles":
        studio_step_card(1, "Formats prédéfinis", "Choisis un format selon la plateforme de destination.")
        st.selectbox("Modèle", ["TikTok 9:16", "Reels 9:16", "Shorts 9:16", "YouTube 16:9"], key="model_tpl")
        st.caption("Le format sera appliqué à ton export vidéo.")

def page_perso():
    st.markdown("### 🎨 Personnaliser Andrea")
    if st.session_state.pop("perso_saved", False):
        st.success("Personnalisation enregistrée : Andrea l'utilisera dans toutes tes discussions.")
    p = st.session_state.prefs or {}
    styles = list(STYLE_HINT)
    profs = [k for k,_ in PROFILE_OPTIONS]
    plan = st.session_state.plan
    allowed = PLAN_ALLOWED_USE_CASES.get(plan, ("general",))
    ucs = [k for k,_ in USE_CASE_OPTIONS if k in allowed]
    if not ucs:
        ucs = ["general"]
    with st.form("form_perso"):
        nom = st.text_input("Comment Andrea doit-elle t'appeler ?", value=p.get("display_name") or "", max_chars=40)
        style = st.selectbox("Style de réponse", styles, index=styles.index(p["style"]) if p.get("style") in styles else 0)
        objectif = st.text_input("Objectif principal", value=p.get("goal") or "", max_chars=160, placeholder="Ex : arrêter de procrastiner sur mes vidéos")
        prof = st.selectbox("Profil", profs, index=profs.index(p["profile_type"]) if p.get("profile_type") in profs else 0,
                            format_func=lambda x: dict(PROFILE_OPTIONS)[x])
        uc = st.selectbox("Ton but avec Andrea", ucs, index=ucs.index(p["use_case"]) if p.get("use_case") in ucs else len(ucs)-1,
                          format_func=lambda x: USE_CASE_LABEL.get(x, x))
        school_country = None
        if uc == "scolaire":
            cur_pays = p.get("school_country")
            school_country = st.selectbox("Pays du programme scolaire", SCHOOL_COUNTRIES,
                                          index=SCHOOL_COUNTRIES.index(cur_pays) if cur_pays in SCHOOL_COUNTRIES else 0)
        study_country = None
        study_level = None
        if prof == "etudiant":
            cur_study_country = p.get("study_country")
            cur_study_level = p.get("study_level")
            study_country = st.selectbox("Pays d'études", STUDY_COUNTRIES,
                                          index=STUDY_COUNTRIES.index(cur_study_country) if cur_study_country in STUDY_COUNTRIES else 0)
            study_level = st.selectbox("Niveau d'étude", STUDY_LEVELS,
                                       index=STUDY_LEVELS.index(cur_study_level) if cur_study_level in STUDY_LEVELS else 0)
        ok = st.form_submit_button("Enregistrer", use_container_width=True)
    if ok:
        row = {"user_id": uid(), "display_name": clean_text(nom, 40), "style": style, "goal": clean_text(objectif, 160),
               "profile_type": prof, "use_case": uc, "updated_at": now_iso()}
        if uc == "scolaire" and school_country:
            row["school_country"] = school_country
        if prof == "etudiant" and study_country and study_level:
            row["study_country"] = study_country
            row["study_level"] = study_level
        try:
            sb().table("preferences").upsert(row, on_conflict="user_id").execute()
            st.session_state.prefs = {k: row.get(k) for k in ("display_name", "style", "goal", "profile_type", "use_case", "school_country", "study_country", "study_level")}
            st.session_state.profile_type = prof
            st.session_state.perso_saved = True
        except Exception as e:
            db_error(e)
            return
        st.rerun()

def page_parametres():
    st.markdown("### ⚙️ Paramètres du Moteur IA")
    st.caption("Ajuste les hyperparamètres, le modèle, la température et les instructions système comme dans les outils IA avancés.")

    t1, t2, t3, t4 = st.tabs(["⚡ Inférence & Hyperparamètres", "🧠 Persona & Instructions", "🛠️ Outils & Capacités", "🛡️ Confidentialité"])
    
    with t1:
        st.markdown("#### ⚡ Modèle et Échantillonnage LLM")
        c_m1, c_m2 = st.columns(2)
        with c_m1:
            m_choices = ["⚡ Llama instant (Rapide 8B)", "🧠 Puissant (Raisonnement 70B)", "⚡ Mixtral 8x7B (MoE)", "🚀 Gemma 2 (27B Google)"]
            curr_m_idx = 0 if st.session_state.model_choice == "rapide" else 1
            sel_m = st.selectbox("Modèle actif", m_choices, index=curr_m_idx, key="param_model_sel")
            st.session_state.model_choice = "rapide" if "instant" in sel_m.lower() else "puissant"
        with c_m2:
            st.selectbox("Fenêtre de contexte", ["128k tokens (Recommandé)", "32k tokens", "8k tokens"], key="param_ctx_win")

        st.divider()
        st.markdown("#### 🎛️ Hyperparamètres de génération")
        c_s1, c_s2 = st.columns(2)
        with c_s1:
            cur_temp = float(st.session_state.get("ai_temperature", 0.7))
            new_temp = st.slider("Température (Créativité)", min_value=0.0, max_value=1.5, value=cur_temp, step=0.05,
                                 help="0.0 = Déterministe et logique stricte, 0.7 = Équilibré (recommandé), 1.2+ = Haute créativité.")
            st.session_state.ai_temperature = new_temp
            
            cur_tp = float(st.session_state.get("ai_top_p", 0.9))
            new_tp = st.slider("Top-P (Nucleus Sampling)", min_value=0.1, max_value=1.0, value=cur_tp, step=0.05,
                               help="Contrôle la diversité du vocabulaire échantillonné.")
            st.session_state.ai_top_p = new_tp

        with c_s2:
            cur_max_t = int(st.session_state.get("ai_max_tokens", 4096))
            new_max_t = st.slider("Longueur maximale de réponse (tokens)", min_value=512, max_value=8192, value=cur_max_t, step=256)
            st.session_state.ai_max_tokens = new_max_t

            cur_fp = float(st.session_state.get("ai_freq_penalty", 0.2))
            new_fp = st.slider("Pénalité de fréquence (Anti-répétition)", min_value=0.0, max_value=2.0, value=cur_fp, step=0.1)
            st.session_state.ai_freq_penalty = new_fp

        st.checkbox("Streaming en direct mot à mot", value=True, key="param_stream_toggle")
        st.checkbox("Afficher la chaîne de pensée interne (Chain-of-Thought CoT)", value=False, key="param_cot_toggle")

    with t2:
        st.markdown("#### 🧠 Persona & Instructions Système")
        persona = st.selectbox("Posture psychologique", ["BehaviorLab AI (Neurosciences & Déblocage)", "Expert & Stratège (Analytique & ROI)", "Tuteur Socratique (Questions réflexives)", "Neutre & Synthétique"], key="param_persona")
        custom_inst = st.text_area(
            "Instructions système personnalisées (System Prompt)",
            value=st.session_state.get("ai_system_instructions", "Adopte la méthode BehaviorLab AI : identifie le levier comportemental précis avant de proposer un plan d'action en 3 étapes concrètes."),
            height=130,
            key="param_sys_inst"
        )
        st.session_state.ai_system_instructions = custom_inst

        c_p1, c_p2 = st.columns(2)
        with c_p1:
            st.selectbox("Format de réponse préféré", ["Équilibré & Actionnable", "Ultra-concis (Moins de 150 mots)", "Exhaustif & Détaillé"], key="param_fmt")
        with c_p2:
            st.selectbox("Langage et style de code", ["TypeScript strict (React/Node)", "Python typé (Streamlit/FastAPI)", "Full-Stack polyvalent"], key="param_code_style")

    with t3:
        st.markdown("#### 🛠️ Outils & Capacités Avancées")
        st.checkbox("🌐 Recherche Web en direct (Grounding)", value=True, key="param_web", help="Permet à l'IA de sourcer des données et faits récents.")
        st.checkbox("💻 Interpréteur & Analyseur de code AST", value=True, key="param_code_interp", help="Validation automatique de la syntaxe avant exécution.")
        st.checkbox("🧠 Détection des blocages comportementaux", value=True, key="param_behav_detect", help="Active l'analyse cognitive et le micro-défi.")
        st.checkbox("🎙️ Dictée vocale continue Whisper", value=True, key="param_stt", help="Microphone gratuit 36px.")
        st.checkbox("💾 Mémoire continue inter-sessions", value=True, key="param_mem_toggle", help="Retient les objectifs entre chaque connexion.")

    with t4:
        st.markdown("#### 🛡️ Protection des Données & Confidentialité")
        st.info("🔒 **Zéro Data Retention** : Tes discussions et tes prompts ne sont jamais utilisés pour entraîner des modèles publics d'IA.")
        st.checkbox("Sauvegarder l'historique sur mon compte", value=True, key="param_save_hist")
        st.checkbox("Chiffrement local des mémoires (Anti-XSS)", value=True, key="param_local_enc")
        if st.button("🔄 Réinitialiser tous les paramètres aux valeurs recommandées", key="param_reset_all"):
            st.session_state.ai_temperature = 0.7
            st.session_state.ai_top_p = 0.9
            st.session_state.ai_max_tokens = 4096
            st.session_state.model_choice = "rapide"
            st.toast("Paramètres réinitialisés avec succès !")
            st.rerun()

    if st.button("💾 Enregistrer la configuration", type="primary", key="save_params_btn", use_container_width=True):
        st.success("Configuration de l'IA enregistrée et appliquée immédiatement.")

def page_compte():
    st.markdown("### 💎 Compte & offres")
    q = st.session_state.quota or {}
    st.markdown(f"**Offre actuelle :** {PLAN_LABEL[st.session_state.plan]}")
    if st.button("🔄 Actualiser mon offre", key="refresh_plan"):
        refresh_quota()
        st.rerun()
    for k, label in (("chat", "Requêtes de chat"), ("code", "Requêtes IA code")):
        if q.get(k):
            st.progress(min(q[k]["used"] / max(q[k]["limit"], 1), 1.0), text=f"{label} ce mois-ci : {q[k]['used']}/{q[k]['limit']}")
    st.caption("Après un paiement, ton offre est activée sur ton compte (si ce n'est pas le cas, contacte le support).")
    render_offers()
    st.divider()
    st.markdown("#### 🔒 Confidentialité")
    st.markdown(privacy_md())
    st.caption("Texte indicatif : à faire valider et compléter (mentions légales, CGU, politique de confidentialité complète) avant l'ouverture au public.")
    confirm = st.checkbox("Je confirme vouloir supprimer toutes mes discussions et tous mes projets de code", key="del_all_ok")
    if st.button("Supprimer mon historique", key="del_all", disabled=not confirm):
        try:
            sb().table("conversations").delete().eq("user_id", uid()).execute()
            sb().table("code_projects").delete().eq("user_id", uid()).execute()
            st.session_state.convs = st.session_state.projects = None
            new_chat()
            st.session_state.page = "compte"
            st.success("Historique supprimé.")
        except Exception as e:
            db_error(e)

if not logged_in():
    restore_auth_session()

if not logged_in():
    page_vitrine()
    st.stop()

if st.session_state.is_admin and st.session_state.dev_mode is None:
    st.session_state.page = "dev_portal"

if st.session_state.page == "dev_portal":
    page_dev_portal()
    st.stop()
if st.session_state.page == "dev_lab":
    page_dev_lab()
    st.stop()

if not st.session_state.get("onboarding_done") and not (st.session_state.prefs or {}).get("use_case") and not st.session_state.is_admin:
    page_onboarding()
    st.stop()

render_sidebar()
{
    "chat": page_chat, "code": page_code, "app": page_app, "studio": page_studio,
    "projets": page_projets, "perso": page_perso, "compte": page_compte, "memoire": page_memoire,
    "parametres": page_parametres, "dev_portal": page_dev_portal, "dev_lab": page_dev_lab,
}.get(st.session_state.page, page_chat)()